(function () {
  const tabs = [...document.querySelectorAll('[data-app-tab]')].filter((tab) => tab.dataset.featureDisabled !== 'true');
  const panels = [...document.querySelectorAll('[data-app-panel]')];
  const validTabs = new Set(tabs.map((tab) => tab.dataset.appTab));
  const context = document.querySelector('#workspaceContext');
  const statusContext = document.querySelector('#statusContext');

  function activateTab(name, updateHash = true) {
    const next = validTabs.has(name) ? name : 'calculator';
    tabs.forEach((tab) => {
      const active = tab.dataset.appTab === next;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', String(active));
      tab.tabIndex = active ? 0 : -1;
    });
    panels.forEach((panel) => {
      const active = panel.dataset.appPanel === next;
      panel.hidden = !active;
      panel.classList.toggle('active', active);
    });
    const activeTab = tabs.find((tab) => tab.dataset.appTab === next);
    const contextLabel = activeTab?.dataset.context || activeTab?.textContent.trim() || '工作台';
    if (context) context.textContent = contextLabel;
    if (statusContext) statusContext.textContent = `${contextLabel}就绪`;
    window.requestAnimationFrame(() => activeTab?.scrollIntoView({ block: 'nearest', inline: 'nearest' }));
    document.querySelector('#clearAll').hidden = next !== 'comparison';
    if (updateHash && window.location.hash !== `#${next}`) history.replaceState(null, '', `#${next}`);
    window.dispatchEvent(new CustomEvent('app-tab-change', { detail: { tab: next } }));
  }

  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => activateTab(tab.dataset.appTab));
    tab.addEventListener('keydown', (event) => {
      if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
      event.preventDefault();
      const direction = event.key === 'ArrowRight' ? 1 : -1;
      const target = tabs[(index + direction + tabs.length) % tabs.length];
      activateTab(target.dataset.appTab);
      target.focus();
    });
  });

  document.addEventListener('click', (event) => {
    const control = event.target.closest('[data-switch-tab]');
    if (control) activateTab(control.dataset.switchTab);
  });
  window.addEventListener('hashchange', () => activateTab(window.location.hash.slice(1), false));

  const clock = document.querySelector('#clockStatus');
  const updateClock = () => { clock.textContent = new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date()); };
  updateClock();
  window.setInterval(updateClock, 30000);
  activateTab(window.location.hash.slice(1), false);
})();
