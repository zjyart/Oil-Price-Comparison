#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 -m http.server 4190 --bind 127.0.0.1 &
server_pid=$!
sleep 1
open "http://127.0.0.1:4190/index.html"
wait "$server_pid"
