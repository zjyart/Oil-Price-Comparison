(function () {
function readStorage(key, fallback) { try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch { return fallback; } }
function validPoint(point) { return point && Number.isFinite(Number(point.lat)) && Number.isFinite(Number(point.lng)) && Math.abs(Number(point.lat)) <= 90 && Math.abs(Number(point.lng)) <= 180; }
function distanceKm(a, b) {
  const radians = (degrees) => degrees * Math.PI / 180;
  const lat1 = radians(Number(a.lat)); const lat2 = radians(Number(b.lat));
  const deltaLat = lat2 - lat1; const deltaLng = radians(Number(b.lng) - Number(a.lng));
  const value = Math.sin(deltaLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
}
function escapeHtml(value) { const div = document.createElement('div'); div.textContent = value; return div.innerHTML; }
function displayPlanName(record) {
  const name = String(record?.name || '未命名方案').trim();
  const brand = String(record?.brand || '').trim();
  const repeatedPrefix = brand ? `${brand} ${brand}` : '';
  return repeatedPrefix && name.startsWith(repeatedPrefix) ? `${brand}${name.slice(repeatedPrefix.length)}` : name;
}
function displayStationName(record, locationName = '') {
  const cleanLocation = String(locationName).trim();
  if (cleanLocation && !/^(地图选点|地图位置|选中位置)$/.test(cleanLocation)) return cleanLocation;
  const brand = String(record?.brand || '').trim();
  const store = String(record?.store || '').trim();
  if (store) return brand && !store.replace(/\s+/g, '').includes(brand.replace(/\s+/g, '')) ? `${brand} ${store}` : store;
  return displayPlanName(record).replace(/\s*·\s*[^·]+$/, '').trim();
}
function refreshIcons() { if (window.lucide) window.lucide.createIcons(); }
const money = (value) => `¥${value.toFixed(2)}`;

let records = [];
const storedProfile = readStorage('fuel-car-profile', {});
const profile = {
  consumption: Math.max(.1, Number(storedProfile?.consumption) || 7.5),
  distances: storedProfile?.distances && typeof storedProfile.distances === 'object' ? storedProfile.distances : {},
  locations: storedProfile?.locations && typeof storedProfile.locations === 'object' ? storedProfile.locations : {},
  origin: validPoint(storedProfile?.origin) ? { lat: Number(storedProfile.origin.lat), lng: Number(storedProfile.origin.lng) } : null,
  coordinateSystem: 'gcj02',
};
const storedSettings = readStorage('fuel-app-settings', {});
const settings = {
  autoLocate: storedSettings.autoLocate === true,
  showLabels: storedSettings.showLabels !== false,
  preferDriving: storedSettings.preferDriving !== false,
  mapMode: ['standard', 'driving', 'satellite'].includes(storedSettings.mapMode) ? storedSettings.mapMode : 'standard',
  traffic: storedSettings.traffic === true,
  rememberTrip: storedSettings.rememberTrip !== false,
  autoPrice: storedSettings.autoPrice !== false,
  defaultTripMode: ['oneWay', 'roundTrip'].includes(storedSettings.defaultTripMode) ? storedSettings.defaultTripMode : 'oneWay',
  stationSearchRadius: [8, 20, 50].includes(Number(storedSettings.stationSearchRadius)) ? Number(storedSettings.stationSearchRadius) : 8,
  autoExpandSearch: storedSettings.autoExpandSearch === true,
  autoFitRoute: storedSettings.autoFitRoute !== false,
};
const storedTripState = readStorage('fuel-trip-state', {});
let correctionMode = 'oneWay';
let sortMode = 'cost';
let selectedAdjustedId = '';
let selectedComparisonId = '';
let activeComparisonView = 'base';
let map;
let comparisonMap;
let comparisonMapMarkers = [];
let comparisonOriginMarker;
let comparisonRouteLayer;
let comparisonPendingDriving;
let comparisonRouteRequestId = 0;
let amapLoadPromise;
let geolocationService;
let placeSearchService;
let routeLayer;
const mapDisplayLayers = new WeakMap();
let tripOrigin = settings.rememberTrip && validPoint(storedTripState.origin) ? storedTripState.origin : profile.origin ? { ...profile.origin, name: '上次使用的位置' } : null;
let tripDestination = settings.rememberTrip && validPoint(storedTripState.destination) ? storedTripState.destination : null;
let tripBaseDistance = 0;
let tripBaseDuration = 0;
let tripMode = settings.defaultTripMode;
let activeMapPoint = tripOrigin ? 'destination' : 'origin';
let tripMarkers = { origin: null, destination: null };
let searchCandidates = [];
let searchTarget = 'origin';
let searchRequestId = 0;
let searchDebounceTimer;
let toastTimer;

const consumptionInput = document.querySelector('#consumption');
const tripConsumptionInput = document.querySelector('#tripConsumption');
const fuelPriceInput = document.querySelector('#fuelPrice');
const tripDistanceInput = document.querySelector('#tripDistance');

function saveProfile() { localStorage.setItem('fuel-car-profile', JSON.stringify(profile)); }
function saveSettings() { localStorage.setItem('fuel-app-settings', JSON.stringify(settings)); }
function saveTripState() { if (settings.rememberTrip) localStorage.setItem('fuel-trip-state', JSON.stringify({ origin: tripOrigin, destination: tripDestination })); }
function showToast(message) { const toast = document.querySelector('#toast'); toast.querySelector('span').textContent = message; toast.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 1700); }

function normalizeRecords() {
  const stored = readStorage('fuel-comparisons', []);
  records = (Array.isArray(stored) ? stored : []).map((record) => ({ ...record, price: Number(record.price), liters: Number(record.liters), spent: Number(record.spent), effective: Number(record.effective) || Number(record.spent) / Number(record.liters) })).filter((record) => [record.price, record.liters, record.spent, record.effective].every((value) => Number.isFinite(value) && value > 0));
  document.querySelector('#navCount').textContent = records.length;
  if ((settings.autoPrice || !fuelPriceInput.value) && records.length) fuelPriceInput.value = Math.min(...records.map((record) => record.effective)).toFixed(2);
}

function calculateStation(record) {
  const distance = Math.max(0, Number(profile.distances[record.id]) || 0);
  const factor = correctionMode === 'roundTrip' ? 2 : 1;
  const routeFuel = distance * factor * profile.consumption / 100;
  const tripCost = routeFuel * record.effective;
  const adjustedTotal = record.spent + tripCost;
  return { ...record, distance, routeFuel, tripCost, adjustedTotal, adjustedEffective: adjustedTotal / record.liters };
}

function renderCorrectionViews() {
  const chart = document.querySelector('#carChart');
  const list = document.querySelector('#stationCostList');
  chart.innerHTML = '';
  list.innerHTML = '';
  if (!records.length) {
    const empty = '<div class="comparison-view-empty"><i data-lucide="route"></i><strong>还没有可修正的方案</strong><span>先在计算页添加一个方案</span></div>';
    chart.innerHTML = empty;
    list.innerHTML = empty;
    refreshIcons();
    return;
  }
  const stations = records.map(calculateStation).sort((a, b) => sortMode === 'distance' ? a.distance - b.distance : a.adjustedEffective - b.adjustedEffective);
  if (!stations.some((station) => String(station.id) === String(selectedAdjustedId))) selectedAdjustedId = String(stations[0]?.id || '');
  const best = Math.min(...stations.map((station) => station.adjustedEffective));
  const max = Math.max(...stations.map((station) => station.adjustedEffective), 1);
  const min = Math.min(...stations.map((station) => station.adjustedEffective));
  const spread = Math.max(max - min, max * .08);
  stations.forEach((station, index) => {
    const isBest = Math.abs(station.adjustedEffective - best) < .001;
    const row = document.createElement('article');
    row.className = `chart-row ${isBest ? 'best' : ''} ${String(station.id) === String(selectedAdjustedId) ? 'selected' : ''}`;
    row.dataset.recordId = station.id;
    const relativeWidth = 8 + (station.adjustedEffective - min) / spread * 84;
    const name = escapeHtml(displayPlanName(station));
    row.innerHTML = `<span class="chart-label" title="${name}">${name}</span><div class="chart-track"><span class="chart-bar" style="--bar-width:${Math.min(100, relativeWidth)}%"></span></div><strong class="chart-value">${station.adjustedEffective.toFixed(2)}</strong><span class="row-actions"><button class="row-edit-action" type="button" data-edit-record="${station.id}" aria-label="编辑方案"><i data-lucide="pencil"></i></button><button class="row-delete-action" type="button" data-delete-record="${station.id}" aria-label="删除方案"><i data-lucide="trash-2"></i></button></span>`;
    chart.appendChild(row);

    const location = profile.locations[station.id];
    const routeLabel = location?.source === 'amap-driving' ? '高德驾车路线' : location?.source === 'straight-line' ? '直线估算' : '已锚定位置';
    const card = document.createElement('article');
    card.className = `station-cost-card ${isBest ? 'best' : ''} ${String(station.id) === String(selectedAdjustedId) ? 'selected' : ''}`;
    card.dataset.recordId = station.id;
    const displayName = displayPlanName(station);
    const routeDistance = station.distance * (correctionMode === 'roundTrip' ? 2 : 1);
    const routeMinutes = routeDistance > 0 ? Math.max(1, Math.round(routeDistance / 40 * 60)) : 0;
    const routeSummary = station.distance > 0 ? `${correctionMode === 'roundTrip' ? '往返' : '单程'} ${routeDistance.toFixed(1)} km · 约 ${routeMinutes} 分钟` : '距离未填写，暂不估算时间';
    card.innerHTML = `<div class="station-card-head"><div><span class="rank ${isBest ? 'best' : ''}">${String(index + 1).padStart(2, '0')}</span><div><h3>${escapeHtml(displayName)}${isBest ? '<em>当前最低</em>' : ''}</h3><p>原真实油价 ${money(station.effective)}/升${location?.name ? ` · ${escapeHtml(location.name)} · ${routeLabel}` : ' · 尚未绑定地图位置'}</p><small class="route-summary">${routeSummary}</small></div></div><label class="distance-editor-inline"><span>单程距离</span><div><input class="distance-input" data-id="${station.id}" type="number" min="0" step="0.1" inputmode="decimal" value="${station.distance || ''}" placeholder="选填" aria-label="${escapeHtml(displayName)}单程距离" /><b>km</b></div></label></div><div class="trip-metrics"><div><span>${correctionMode === 'roundTrip' ? '往返' : '单程'}预计耗油</span><strong>${station.routeFuel.toFixed(3)} L</strong></div><div><span>路程油费</span><strong>${money(station.tripCost)}</strong></div><div><span>加油支出</span><strong>${money(station.spent)}</strong></div><div class="primary-metric"><span>距离修正单价</span><strong>${money(station.adjustedEffective)} /升</strong></div></div><div class="cost-equation"><span>加油支出 ${money(station.spent)}</span><i data-lucide="plus"></i><span>路程油费 ${money(station.tripCost)}</span><i data-lucide="equal"></i><strong>${money(station.adjustedTotal)}</strong></div>`;
    list.appendChild(card);
  });
  document.querySelector('#distanceHint').textContent = '';
  refreshIcons();
}

function activateComparisonView(name) {
  activeComparisonView = name;
  const mapPreview = document.querySelector('#comparisonMapPreview');
  const layout = mapPreview?.parentElement;
  if (name === 'manager') {
    if (mapPreview) mapPreview.hidden = true;
    layout?.classList.remove('map-open');
  } else {
    if (mapPreview) mapPreview.hidden = false;
    layout?.classList.add('map-open');
    if (records.length) window.setTimeout(() => showComparisonStationMap(selectedComparisonId || selectedAdjustedId || records[0]?.id), 0);
  }
  document.querySelectorAll('[data-comparison-view]').forEach((button) => {
    const active = button.dataset.comparisonView === name;
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
  });
  document.querySelectorAll('[data-comparison-panel]').forEach((panel) => {
    const active = panel.dataset.comparisonPanel === name;
    panel.hidden = !active;
    panel.classList.toggle('active', active);
  });
  if (name === 'adjusted') renderCorrectionViews();
  window.dispatchEvent(new CustomEvent('comparison-view-change', { detail: { view: name } }));
}

function setMapStatus(message, state = '') {
  const status = document.querySelector('#mapStatus');
  status.className = state;
  status.querySelector('span').textContent = message;
}

function loadAmap() {
  if (amapLoadPromise) return amapLoadPromise;
  amapLoadPromise = window.FuelAmap
    ? window.FuelAmap.load(['AMap.Geolocation', 'AMap.Driving', 'AMap.PlaceSearch'])
    : Promise.reject(new Error('amap-service-unavailable'));
  return amapLoadPromise;
}

function pointMarkerContent(type, point) {
  const label = settings.showLabels ? `<small>${escapeHtml(point.name || (type === 'origin' ? '行程起点' : '行程终点'))}</small>` : '';
  return `<div class="trip-point-marker ${type}"><span>${type === 'origin' ? '起' : '终'}</span>${label}</div>`;
}

function renderTripMarkers() {
  if (!map || !window.AMap) return;
  Object.entries(tripMarkers).forEach(([type, marker]) => { if (marker) map.remove(marker); tripMarkers[type] = null; });
  [['origin', tripOrigin], ['destination', tripDestination]].forEach(([type, point]) => {
    if (!validPoint(point)) return;
    const marker = new window.AMap.Marker({ position: [point.lng, point.lat], anchor: 'bottom-center', zIndex: type === 'origin' ? 130 : 140, content: pointMarkerContent(type, point) });
    tripMarkers[type] = marker;
    map.add(marker);
  });
}

function updatePointMode() {
  document.querySelectorAll('[data-map-point]').forEach((button) => button.classList.toggle('active', button.dataset.mapPoint === activeMapPoint));
}

function updateTripSummary({ syncDistance = false } = {}) {
  const factor = tripMode === 'roundTrip' ? 2 : 1;
  const routeKm = tripBaseDistance * factor;
  if (syncDistance) tripDistanceInput.value = routeKm ? routeKm.toFixed(1) : '';
  const enteredDistance = Number(tripDistanceInput.value);
  const km = Number.isFinite(enteredDistance) && enteredDistance >= 0 && tripDistanceInput.value !== '' ? enteredDistance : routeKm;
  const routeSeconds = tripBaseDuration * factor;
  const seconds = routeKm > 0 ? routeSeconds * km / routeKm : routeSeconds;
  const price = Number(fuelPriceInput.value) || 0;
  const consumption = Math.max(.1, Number(tripConsumptionInput.value) || profile.consumption);
  const liters = km * consumption / 100;
  const cost = liters * price;
  const averageSpeed = seconds > 0 ? km / (seconds / 3600) : 0;
  document.querySelector('#tripFuel').textContent = km ? `${liters.toFixed(2)} L` : '-- L';
  document.querySelector('#tripCost').textContent = km && price ? money(cost) : '--';
  document.querySelector('#costPerKm').textContent = km && price ? `${money(cost / km)} / km` : '--';
  document.querySelector('#tripDuration').textContent = seconds ? formatDuration(seconds) : '--';
  document.querySelector('#costPer100Km').textContent = price ? money(consumption * price) : '--';
  document.querySelector('#tripAverageSpeed').textContent = averageSpeed ? `${averageSpeed.toFixed(0)} km/h` : '-- km/h';
  const routeText = tripOrigin && tripDestination ? `${tripOrigin.name || '起点'} → ${tripDestination.name || '终点'}${tripMode === 'roundTrip' ? ' · 往返' : ''}` : tripOrigin ? '请选择行程终点' : '等待设置起终点';
  document.querySelector('#tripRouteLabel').textContent = routeText;
  if (searchTarget === 'destination' && searchCandidates.length) renderTripSearchResults();
}

function formatDuration(seconds) {
  const minutes = Math.max(1, Math.round(Number(seconds) / 60));
  if (minutes < 60) return `${minutes} 分钟`;
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  return remainder ? `${hours} 小时 ${remainder} 分` : `${hours} 小时`;
}

function clearRouteLayer() { if (routeLayer) { routeLayer.clear(); routeLayer = null; } }

function createEnergyRoute(targetMap, route, fitObjects = []) {
  const path = (route?.steps || []).flatMap((step) => Array.isArray(step?.path) ? step.path : []);
  if (!path.length || !targetMap || !window.AMap?.Polyline) return null;
  const polyline = new window.AMap.Polyline({
    map: targetMap,
    path,
    zIndex: 90,
    strokeColor: '#ff5a36',
    strokeOpacity: .96,
    strokeWeight: 7,
    borderWeight: 3,
    outlineColor: '#35140e',
    isOutline: true,
    lineJoin: 'round',
    lineCap: 'round',
    showDir: true,
  });
  if (settings.autoFitRoute && fitObjects.length) targetMap.setFitView([polyline, ...fitObjects].filter(Boolean), false, [64, 64, 64, 64], 16);
  return { clear: () => targetMap.remove(polyline), polyline };
}

async function calculateTripRoute() {
  clearRouteLayer();
  if (!validPoint(tripOrigin) || !validPoint(tripDestination)) { tripBaseDistance = 0; tripBaseDuration = 0; updateTripSummary({ syncDistance: true }); return; }
  setMapStatus('正在计算驾车路线…', 'loading');
  let usedDriving = false;
  if (settings.preferDriving) {
    try {
      const route = await new Promise((resolve, reject) => {
        const driving = new window.AMap.Driving({ hideMarkers: true, showTraffic: false, policy: window.AMap.DrivingPolicy.LEAST_TIME });
        driving.search(new window.AMap.LngLat(tripOrigin.lng, tripOrigin.lat), new window.AMap.LngLat(tripDestination.lng, tripDestination.lat), (status, result) => {
          const first = result?.routes?.[0];
          if (status === 'complete' && Number.isFinite(Number(first?.distance))) {
            routeLayer = createEnergyRoute(map, first, Object.values(tripMarkers));
            driving.clear();
            if (!routeLayer) { reject(new Error('route-path')); return; }
            resolve({ distance: Number(first.distance) / 1000, duration: Number(first.time) || 0 });
          } else { driving.clear(); reject(new Error('route')); }
        });
      });
      tripBaseDistance = route.distance;
      tripBaseDuration = route.duration;
      usedDriving = true;
    } catch { tripBaseDistance = distanceKm(tripOrigin, tripDestination); tripBaseDuration = tripBaseDistance / 50 * 3600; }
  } else { tripBaseDistance = distanceKm(tripOrigin, tripDestination); tripBaseDuration = tripBaseDistance / 50 * 3600; }
  updateTripSummary({ syncDistance: true });
  if (settings.autoFitRoute && !usedDriving) map.setFitView(Object.values(tripMarkers).filter(Boolean), false, [80, 80, 80, 80], 15);
  setMapStatus(`${tripBaseDistance.toFixed(1)} km · ${usedDriving ? '高德驾车路线' : '直线距离估算'}`, usedDriving ? 'ready' : 'error');
}

function setTripPoint(type, point, name) {
  const value = { lat: Number(point.lat), lng: Number(point.lng), name: name || (type === 'origin' ? '地图起点' : '地图终点') };
  if (type === 'origin') {
    tripOrigin = value;
    profile.origin = { lat: value.lat, lng: value.lng };
    saveProfile();
    document.querySelector('#tripOriginQuery').value = value.name;
    activeMapPoint = 'destination';
  } else {
    tripDestination = value;
    document.querySelector('#tripDestinationQuery').value = value.name;
  }
  saveTripState();
  updatePointMode();
  renderTripMarkers();
  if (tripOrigin && tripDestination) calculateTripRoute();
  else {
    updateTripSummary({ syncDistance: true });
    setMapStatus(type === 'origin' ? '起点已设置，请选择或搜索终点' : '终点已设置，请选择起点', 'ready');
    map.setZoomAndCenter(Math.max(map.getZoom(), 14), [value.lng, value.lat]);
  }
}

function applyAppearance() {
  document.body.classList.remove('night-mode');
  document.documentElement.style.colorScheme = 'dark';
}

function createCurrentDefaultLayer() {
  const options = { zooms: [2, 20], opacity: 1, zIndex: 0, detectRetina: true };
  return typeof window.AMap.createDefaultLayer === 'function' ? window.AMap.createDefaultLayer(options) : new window.AMap.TileLayer(options);
}

function applyDisplayToMap(targetMap) {
  if (!targetMap || !window.AMap) return;
  try {
    const previous = mapDisplayLayers.get(targetMap);
    if (previous?.traffic) targetMap.remove(previous.traffic);
    let baseLayers;
    if (settings.mapMode === 'satellite' && window.AMap.TileLayer?.Satellite) {
      baseLayers = [new window.AMap.TileLayer.Satellite({ zooms: [2, 20], zIndex: 0 })];
      if (window.AMap.TileLayer?.RoadNet) baseLayers.push(new window.AMap.TileLayer.RoadNet({ zooms: [2, 20], zIndex: 1 }));
      targetMap.setLayers(baseLayers);
    } else {
      baseLayers = [createCurrentDefaultLayer()];
      targetMap.setLayers(baseLayers);
      targetMap.setMapStyle('amap://styles/dark');
      if (typeof targetMap.setFeatures === 'function') targetMap.setFeatures(settings.mapMode === 'driving' ? ['bg', 'road', 'building'] : ['bg', 'road', 'building', 'point']);
    }
    let traffic = null;
    if (settings.traffic && window.AMap.TileLayer?.Traffic) {
      traffic = new window.AMap.TileLayer.Traffic({ zIndex: 12, autoRefresh: true, interval: 180 });
      targetMap.add(traffic);
    }
    mapDisplayLayers.set(targetMap, { baseLayers, traffic });
    window.setTimeout(() => targetMap.resize(), 0);
  } catch { setMapStatus('地图显示模式切换失败，已保留当前样式', 'error'); }
}

function applyMapDisplay() { applyDisplayToMap(map); }

function applyComparisonMapDisplay() {
  applyDisplayToMap(comparisonMap);
}

function clearComparisonRoute() {
  comparisonRouteRequestId += 1;
  if (comparisonPendingDriving) { comparisonPendingDriving.clear(); comparisonPendingDriving = null; }
  if (comparisonRouteLayer) { comparisonRouteLayer.clear(); comparisonRouteLayer = null; }
  if (comparisonOriginMarker && comparisonMap) { comparisonMap.remove(comparisonOriginMarker); comparisonOriginMarker = null; }
}

function comparisonOriginPoint() {
  return validPoint(tripOrigin) ? tripOrigin : validPoint(profile.origin) ? profile.origin : null;
}

async function drawComparisonRoute(origin, destination) {
  clearComparisonRoute();
  if (!comparisonMap || !window.AMap || !validPoint(origin) || !validPoint(destination)) return null;
  const requestId = comparisonRouteRequestId;
  comparisonOriginMarker = new window.AMap.Marker({ map: comparisonMap, position: [Number(origin.lng), Number(origin.lat)], anchor: 'bottom-center', content: '<div class="comparison-origin-marker"><span>我的位置</span></div>' });
  try {
    const route = await new Promise((resolve, reject) => {
      const driving = new window.AMap.Driving({ hideMarkers: true, showTraffic: settings.traffic, policy: window.AMap.DrivingPolicy.LEAST_TIME });
      comparisonPendingDriving = driving;
      driving.search(new window.AMap.LngLat(Number(origin.lng), Number(origin.lat)), new window.AMap.LngLat(Number(destination.lng), Number(destination.lat)), (status, result) => {
        if (requestId !== comparisonRouteRequestId) { driving.clear(); reject(new Error('stale-route')); return; }
        const first = result?.routes?.[0];
        comparisonPendingDriving = null;
        if (status === 'complete' && Number.isFinite(Number(first?.distance))) {
          comparisonRouteLayer = createEnergyRoute(comparisonMap, first, [comparisonOriginMarker, ...comparisonMapMarkers]);
          driving.clear();
          if (!comparisonRouteLayer) { reject(new Error('route-path')); return; }
          resolve(first);
        } else { driving.clear(); reject(new Error('route')); }
      });
    });
    const oneWayKm = Number(route.distance) / 1000;
    const oneWayMinutes = Math.round(Number(route.time || 0) / 60);
    const factor = correctionMode === 'roundTrip' ? 2 : 1;
    return { distanceKm: oneWayKm * factor, minutes: oneWayMinutes * factor, oneWayKm, oneWayMinutes };
  } catch { return null; }
}

async function showComparisonStationMap(comparisonId) {
  const preview = document.querySelector('#comparisonMapPreview');
  const title = document.querySelector('#comparisonMapTitle');
  const address = document.querySelector('#comparisonMapAddress');
  const empty = document.querySelector('#comparisonMapEmpty');
  const record = records.find((item) => String(item.id) === String(comparisonId));
  if (!preview) return;
  clearComparisonRoute();
  if (record) selectedComparisonId = String(record.id);
  const location = record ? profile.locations[comparisonId] : null;
  const stationName = record ? displayStationName(record, location?.name) : '加油站地图';
  const mappedRecords = records.map((item) => ({ record: item, location: profile.locations[item.id] })).filter((item) => validPoint(item.location));
  title.textContent = stationName;
  address.textContent = mappedRecords.length ? `${mappedRecords.length} 个已定位油站` : '选择方案查看位置';
  preview.hidden = false;
  preview.parentElement?.classList.add('map-open');
  if (!mappedRecords.length) {
    document.querySelector('#comparisonMap').hidden = true;
    empty.hidden = false;
    refreshIcons();
    return;
  }
  document.querySelector('#comparisonMap').hidden = false;
  empty.hidden = true;
  try {
    await loadAmap();
    const selectedLocation = validPoint(location) ? location : mappedRecords[0].location;
    const center = [Number(selectedLocation.lng), Number(selectedLocation.lat)];
    if (!comparisonMap) comparisonMap = new window.AMap.Map('comparisonMap', { viewMode: '2D', center, zoom: 15, resizeEnable: true });
    applyComparisonMapDisplay();
    comparisonMapMarkers.forEach((marker) => comparisonMap.remove(marker));
    comparisonMapMarkers = mappedRecords.map(({ record: item, location: itemLocation }) => {
      const isSelected = String(item.id) === String(comparisonId);
      const itemName = displayStationName(item, itemLocation?.name);
      const marker = new window.AMap.Marker({ map: comparisonMap, position: [Number(itemLocation.lng), Number(itemLocation.lat)], anchor: 'bottom-center', content: `<div class="comparison-map-marker${isSelected ? ' selected' : ''}"><span>${escapeHtml(itemName)}</span></div>` });
      marker.on('click', () => {
        if (activeComparisonView === 'adjusted') selectAdjustedStation(item.id);
        else window.dispatchEvent(new CustomEvent('comparison-map-base-select', { detail: { comparisonId: String(item.id) } }));
      });
      return marker;
    });
    comparisonMap.setCenter(center);
    if (settings.autoFitRoute && comparisonMapMarkers.length > 1) comparisonMap.setFitView(comparisonMapMarkers, false, [34, 34, 34, 34]);
    else comparisonMap.setZoom(15);
    const origin = comparisonOriginPoint();
    const routeSummary = await drawComparisonRoute(origin, validPoint(location) ? location : null);
    if (routeSummary) address.textContent = `${mappedRecords.length} 个油站 · ${routeSummary.distanceKm.toFixed(1)} km · 约 ${routeSummary.minutes} 分钟${correctionMode === 'roundTrip' ? '（往返）' : ''}`;
    else if (origin) address.textContent = `${mappedRecords.length} 个油站 · 已显示我的位置`;
    window.setTimeout(() => comparisonMap.resize(), 0);
  } catch {
    clearComparisonRoute();
    document.querySelector('#comparisonMap').hidden = true;
    empty.hidden = false;
  }
  refreshIcons();
}

async function initMap() {
  if (map) { window.setTimeout(() => map.resize(), 0); return; }
  setMapStatus('正在加载高德地图…', 'loading');
  try {
    await loadAmap();
    const center = tripOrigin ? [tripOrigin.lng, tripOrigin.lat] : [104.1954, 35.8617];
    map = new window.AMap.Map('stationMap', { viewMode: '2D', center, zoom: tripOrigin ? 14 : 4, resizeEnable: true });
    applyMapDisplay();
    map.on('click', (event) => setTripPoint(activeMapPoint, { lng: event.lnglat.getLng(), lat: event.lnglat.getLat() }, activeMapPoint === 'origin' ? '地图起点' : '地图终点'));
    renderTripMarkers();
    if (tripOrigin) document.querySelector('#tripOriginQuery').value = tripOrigin.name;
    if (tripDestination) document.querySelector('#tripDestinationQuery').value = tripDestination.name;
    if (tripOrigin && tripDestination) calculateTripRoute();
    else if (tripOrigin) setMapStatus('已恢复上次起点，请设置终点', 'ready');
    else setMapStatus('点击地图设置起点，或使用位置搜索', 'ready');
    if (settings.autoLocate && !tripOrigin) locateMe();
  } catch (error) {
    setMapStatus(error?.message === 'missing-config' ? '请先在设置中填写高德 API' : '高德地图加载失败，请检查网络与 API 配置', 'error');
  }
}

function locateMe() {
  if (!map || !window.AMap) { setMapStatus('高德地图尚未加载', 'error'); return; }
  setMapStatus('正在获取当前位置…', 'loading');
  if (!geolocationService) geolocationService = new window.AMap.Geolocation({ enableHighAccuracy: true, timeout: 10000, convert: true, showButton: false, showMarker: false, showCircle: false });
  geolocationService.getCurrentPosition((status, result) => {
    if (status !== 'complete' || !result?.position) { setMapStatus('定位未获授权，可搜索或点击地图设置起点', 'error'); return; }
    setTripPoint('origin', { lat: result.position.getLat(), lng: result.position.getLng() }, '当前位置');
    showToast('当前位置已设为起点');
  });
}

function renderTripSearchResults() {
  const results = document.querySelector('#tripSearchResults');
  const factor = tripMode === 'roundTrip' ? 2 : 1;
  const consumption = Math.max(.1, Number(tripConsumptionInput.value) || profile.consumption);
  const price = Number(fuelPriceInput.value) || 0;
  results.innerHTML = searchCandidates.map((point, index) => {
    let estimate = '<span class="trip-result-estimate pending"><em>正在估算路线…</em></span>';
    if (searchTarget !== 'destination') estimate = '';
    else if (!validPoint(tripOrigin)) estimate = '<span class="trip-result-estimate muted"><em>设置起点后显示行程预估</em></span>';
    else if (Number.isFinite(point.routeDistance)) {
      const km = point.routeDistance * factor;
      const seconds = point.routeDuration * factor;
      const cost = km * consumption / 100 * price;
      estimate = `<span class="trip-result-estimate"><em>${km.toFixed(1)} km</em><em>${formatDuration(seconds)}</em><em class="cost">${price ? `约 ${money(cost)}` : '填写油价后估算'}</em></span>`;
    }
    return `<button type="button" role="option" data-trip-result="${index}"><i data-lucide="map-pin"></i><span class="trip-result-copy"><strong>${escapeHtml(point.name)}</strong><small>${escapeHtml(point.address || '地址信息暂缺')}</small>${estimate}</span><i data-lucide="chevron-right"></i></button>`;
  }).join('');
  results.hidden = !searchCandidates.length;
  refreshIcons();
}

function estimateSearchCandidate(point, index, requestId) {
  if (!validPoint(tripOrigin) || !validPoint(point) || requestId !== searchRequestId) return;
  const approximateDistance = distanceKm(tripOrigin, point) * 1.25;
  searchCandidates[index] = {
    ...searchCandidates[index],
    routeDistance: approximateDistance,
    routeDuration: approximateDistance / 45 * 3600,
    approximate: true,
  };
}

async function searchPlace(type, { silent = false } = {}) {
  const input = document.querySelector(type === 'origin' ? '#tripOriginQuery' : '#tripDestinationQuery');
  const query = input.value.trim();
  if (query.length < 2) {
    searchRequestId += 1;
    searchCandidates = [];
    document.querySelector('#tripSearchResults').hidden = true;
    if (!silent) showToast('请输入至少两个字的位置名称');
    return;
  }
  const requestId = ++searchRequestId;
  await initMap();
  if (!window.AMap || requestId !== searchRequestId) return;
  setMapStatus(`正在搜索“${query}”…`, 'loading');
  if (!placeSearchService) placeSearchService = new window.AMap.PlaceSearch({ pageSize: 6, pageIndex: 1, extensions: 'all' });
  const executeSearch = () => new Promise((resolve) => placeSearchService.search(query, (status, result) => resolve(status === 'complete' ? result?.poiList?.pois || [] : [])));
  const searchPromise = window.FuelAmap ? window.FuelAmap.cachedPlaceSearch(`trip:${query}`, executeSearch) : executeSearch();
  searchPromise.then((pois) => {
    if (requestId !== searchRequestId) return;
    searchTarget = type;
    searchCandidates = pois.map((poi) => ({ name: poi.name || query, address: [poi.pname, poi.cityname, poi.adname, poi.address].filter(Boolean).join(' '), lat: Number(poi.location?.getLat?.() ?? poi.location?.lat), lng: Number(poi.location?.getLng?.() ?? poi.location?.lng) })).filter(validPoint);
    if (type === 'destination' && validPoint(tripOrigin)) searchCandidates.forEach((point, index) => estimateSearchCandidate(point, index, requestId));
    renderTripSearchResults();
    setMapStatus(searchCandidates.length ? `找到 ${searchCandidates.length} 个位置，请选择` : '没有找到相近位置，请调整关键词', searchCandidates.length ? 'ready' : 'error');
  }).catch(() => setMapStatus('地点搜索暂时不可用，请稍后再试', 'error'));
}

function schedulePlaceSearch(type) {
  clearTimeout(searchDebounceTimer);
  const input = document.querySelector(type === 'origin' ? '#tripOriginQuery' : '#tripDestinationQuery');
  if (input.value.trim().length < 2) {
    searchRequestId += 1;
    searchCandidates = [];
    document.querySelector('#tripSearchResults').hidden = true;
    return;
  }
  searchDebounceTimer = setTimeout(() => searchPlace(type, { silent: true }), 480);
}

function resetTrip() {
  tripOrigin = null;
  tripDestination = null;
  tripBaseDistance = 0;
  tripBaseDuration = 0;
  localStorage.removeItem('fuel-trip-state');
  activeMapPoint = 'origin';
  clearRouteLayer();
  document.querySelector('#tripOriginQuery').value = '';
  document.querySelector('#tripDestinationQuery').value = '';
  document.querySelector('#tripSearchResults').hidden = true;
  updatePointMode();
  renderTripMarkers();
  updateTripSummary({ syncDistance: true });
  if (map) { map.setZoomAndCenter(4, [104.1954, 35.8617]); setMapStatus('点击地图设置起点，或使用位置搜索', 'ready'); }
}

function swapTripPoints() {
  if (!validPoint(tripOrigin) || !validPoint(tripDestination)) {
    showToast('请先设置完整的起点和终点');
    return;
  }
  [tripOrigin, tripDestination] = [tripDestination, tripOrigin];
  document.querySelector('#tripOriginQuery').value = tripOrigin.name || '行程起点';
  document.querySelector('#tripDestinationQuery').value = tripDestination.name || '行程终点';
  searchCandidates = [];
  document.querySelector('#tripSearchResults').hidden = true;
  saveTripState();
  renderTripMarkers();
  calculateTripRoute();
  showToast('已交换起点和终点');
}

function initSettings() {
  applyAppearance();
  consumptionInput.value = profile.consumption.toFixed(1);
  tripConsumptionInput.value = profile.consumption.toFixed(1);
  document.querySelector('#settingMapMode').value = settings.mapMode;
  document.querySelector('#settingDefaultTripMode').value = settings.defaultTripMode;
  document.querySelector('#settingStationSearchRadius').value = String(settings.stationSearchRadius);
  document.querySelector('#settingAutoLocate').checked = settings.autoLocate;
  document.querySelector('#settingTraffic').checked = settings.traffic;
  document.querySelector('#settingShowLabels').checked = settings.showLabels;
  document.querySelector('#settingPreferDriving').checked = settings.preferDriving;
  document.querySelector('#settingAutoFitRoute').checked = settings.autoFitRoute;
  document.querySelector('#settingAutoExpandSearch').checked = settings.autoExpandSearch;
  document.querySelector('#settingRememberTrip').checked = settings.rememberTrip;
  document.querySelector('#settingAutoPrice').checked = settings.autoPrice;
  document.querySelectorAll('[data-trip-mode]').forEach((button) => button.classList.toggle('active', button.dataset.tripMode === tripMode));

  const customAmap = readStorage('fuel-amap-config', {});
  const amapKeyInput = document.querySelector('#settingAmapKey');
  const amapSecurityInput = document.querySelector('#settingAmapSecurity');
  const amapStatus = document.querySelector('#amapConfigStatus');
  const amapSecretToggle = document.querySelector('#toggleAmapSecrets');
  amapKeyInput.value = customAmap?.key || '';
  amapSecurityInput.value = customAmap?.securityJsCode || '';
  const renderAmapStatus = () => {
    const configured = Boolean(amapKeyInput.value.trim() && amapSecurityInput.value.trim());
    amapStatus.className = configured ? 'ready' : 'error';
    amapStatus.textContent = configured ? '已保存到当前浏览器' : '未配置，地图与油站搜索暂不可用';
  };
  renderAmapStatus();

  document.querySelector('#openSettings').addEventListener('click', () => {
    renderAmapStatus();
    [amapKeyInput, amapSecurityInput].forEach((input) => { input.type = 'password'; });
    amapSecretToggle.setAttribute('aria-pressed', 'false');
    amapSecretToggle.setAttribute('aria-label', '显示高德 API 配置');
    amapSecretToggle.innerHTML = '<i data-lucide="eye"></i>';
    refreshIcons();
    document.querySelector('.settings-content').scrollTop = 0;
    document.querySelector('#settingsDialog').showModal();
  });
  document.querySelector('#closeSettings').addEventListener('click', () => document.querySelector('#settingsDialog').close());
  document.querySelector('#settingsDialog').addEventListener('cancel', (event) => { event.preventDefault(); document.querySelector('#settingsDialog').close(); });
  consumptionInput.addEventListener('input', () => {
    const previousConsumption = profile.consumption;
    profile.consumption = Math.max(.1, Number(consumptionInput.value) || 7.5);
    if (Math.abs((Number(tripConsumptionInput.value) || previousConsumption) - previousConsumption) < .001) tripConsumptionInput.value = profile.consumption.toFixed(1);
    saveProfile();
    renderCorrectionViews();
    updateTripSummary();
  });
  document.querySelector('#settingMapMode').addEventListener('change', (event) => { settings.mapMode = event.target.value; saveSettings(); applyMapDisplay(); applyComparisonMapDisplay(); });
  document.querySelector('#settingDefaultTripMode').addEventListener('change', (event) => { settings.defaultTripMode = event.target.value; tripMode = settings.defaultTripMode; saveSettings(); document.querySelectorAll('[data-trip-mode]').forEach((button) => button.classList.toggle('active', button.dataset.tripMode === tripMode)); updateTripSummary({ syncDistance: true }); });
  document.querySelector('#settingStationSearchRadius').addEventListener('change', (event) => { settings.stationSearchRadius = Number(event.target.value); saveSettings(); });
  document.querySelector('#settingAutoLocate').addEventListener('change', (event) => { settings.autoLocate = event.target.checked; saveSettings(); });
  document.querySelector('#settingTraffic').addEventListener('change', (event) => { settings.traffic = event.target.checked; saveSettings(); applyMapDisplay(); });
  document.querySelector('#settingShowLabels').addEventListener('change', (event) => { settings.showLabels = event.target.checked; saveSettings(); renderTripMarkers(); });
  document.querySelector('#settingPreferDriving').addEventListener('change', (event) => { settings.preferDriving = event.target.checked; saveSettings(); if (tripOrigin && tripDestination) calculateTripRoute(); });
  document.querySelector('#settingAutoFitRoute').addEventListener('change', (event) => { settings.autoFitRoute = event.target.checked; saveSettings(); });
  document.querySelector('#settingAutoExpandSearch').addEventListener('change', (event) => { settings.autoExpandSearch = event.target.checked; saveSettings(); });
  document.querySelector('#settingRememberTrip').addEventListener('change', (event) => { settings.rememberTrip = event.target.checked; saveSettings(); if (settings.rememberTrip) saveTripState(); else localStorage.removeItem('fuel-trip-state'); });
  document.querySelector('#settingAutoPrice').addEventListener('change', (event) => { settings.autoPrice = event.target.checked; saveSettings(); if (settings.autoPrice) normalizeRecords(); });

  amapSecretToggle.addEventListener('click', (event) => {
    const visible = amapKeyInput.type === 'text';
    [amapKeyInput, amapSecurityInput].forEach((input) => { input.type = visible ? 'password' : 'text'; });
    event.currentTarget.setAttribute('aria-pressed', String(!visible));
    event.currentTarget.setAttribute('aria-label', visible ? '显示高德 API 配置' : '隐藏高德 API 配置');
    event.currentTarget.innerHTML = `<i data-lucide="${visible ? 'eye' : 'eye-off'}"></i>`;
    refreshIcons();
  });
  document.querySelector('#saveAmapConfig').addEventListener('click', () => {
    const key = amapKeyInput.value.trim();
    const securityJsCode = amapSecurityInput.value.trim();
    if (!key || !securityJsCode) { amapStatus.textContent = '请同时填写 Web 端 Key 和安全密钥'; amapStatus.className = 'error'; return; }
    localStorage.setItem('fuel-amap-config', JSON.stringify({ key, securityJsCode }));
    amapStatus.textContent = '已保存，正在重新加载地图';
    amapStatus.className = 'ready';
    showToast('高德 API 配置已保存');
    window.setTimeout(() => window.location.reload(), 420);
  });
  document.querySelector('#resetAmapConfig').addEventListener('click', () => {
    localStorage.removeItem('fuel-amap-config');
    amapKeyInput.value = '';
    amapSecurityInput.value = '';
    amapStatus.textContent = '已清除当前浏览器中的 API 配置';
    amapStatus.className = 'error';
    showToast('高德 API 配置已清除');
    window.setTimeout(() => window.location.reload(), 420);
  });
}

document.querySelectorAll('[data-comparison-view]').forEach((button) => button.addEventListener('click', () => activateComparisonView(button.dataset.comparisonView)));
document.querySelectorAll('.mode-button[data-mode]').forEach((button) => button.addEventListener('click', () => { correctionMode = button.dataset.mode; document.querySelectorAll('.mode-button[data-mode]').forEach((item) => item.classList.toggle('active', item === button)); renderCorrectionViews(); if (!document.querySelector('#comparisonMapPreview')?.hidden) showComparisonStationMap(selectedComparisonId || selectedAdjustedId || records[0]?.id); }));
document.querySelector('#sortMode').addEventListener('change', (event) => { sortMode = event.target.value; renderCorrectionViews(); });
function selectAdjustedStation(id) {
  selectedAdjustedId = String(id);
  document.querySelectorAll('#carChart [data-record-id], #stationCostList [data-record-id]').forEach((item) => item.classList.toggle('selected', String(item.dataset.recordId) === selectedAdjustedId));
  document.querySelector(`#carChart [data-record-id="${CSS.escape(selectedAdjustedId)}"]`)?.scrollIntoView({ block: 'nearest' });
  window.dispatchEvent(new CustomEvent('comparison-station-select', { detail: { comparisonId: selectedAdjustedId } }));
}
document.querySelector('#carChart').addEventListener('click', (event) => {
  const edit = event.target.closest('[data-edit-record]');
  const remove = event.target.closest('[data-delete-record]');
  if (edit || remove) return;
  const refuel = event.target.closest('[data-open-refuel]');
  const row = event.target.closest('[data-record-id]');
  if (refuel) { window.dispatchEvent(new CustomEvent('open-refuel-record', { detail: { comparisonId: refuel.dataset.openRefuel } })); return; }
  if (row) selectAdjustedStation(row.dataset.recordId);
});
document.querySelector('#stationCostList').addEventListener('click', (event) => {
  const refuel = event.target.closest('[data-open-refuel]');
  const card = event.target.closest('[data-record-id]');
  if (refuel) { window.dispatchEvent(new CustomEvent('open-refuel-record', { detail: { comparisonId: refuel.dataset.openRefuel } })); return; }
  if (card) selectAdjustedStation(card.dataset.recordId);
});
window.addEventListener('comparison-station-select', (event) => showComparisonStationMap(event.detail?.comparisonId));
function setComparisonMapOpen(open, comparisonId = '') {
  const preview = document.querySelector('#comparisonMapPreview');
  if (!preview) return;
  preview.hidden = false;
  preview.parentElement?.classList.add('map-open');
  showComparisonStationMap(comparisonId || selectedComparisonId || selectedAdjustedId || records[0]?.id);
}
document.querySelector('#stationCostList').addEventListener('input', (event) => { const input = event.target.closest('.distance-input'); if (!input) return; profile.distances[input.dataset.id] = input.value; saveProfile(); });
document.querySelector('#stationCostList').addEventListener('blur', (event) => { const input = event.target.closest('.distance-input'); if (!input) return; profile.distances[input.dataset.id] = Math.max(0, Number(input.value) || 0); saveProfile(); renderCorrectionViews(); showToast('距离已更新'); }, true);
document.querySelectorAll('[data-map-point]').forEach((button) => button.addEventListener('click', () => { activeMapPoint = button.dataset.mapPoint; updatePointMode(); setMapStatus(`请点击地图设置${activeMapPoint === 'origin' ? '起点' : '终点'}`, 'ready'); }));
document.querySelectorAll('[data-trip-mode]').forEach((button) => button.addEventListener('click', () => { tripMode = button.dataset.tripMode; document.querySelectorAll('[data-trip-mode]').forEach((item) => item.classList.toggle('active', item === button)); updateTripSummary({ syncDistance: true }); }));
document.querySelector('#searchTripOrigin').addEventListener('click', () => searchPlace('origin'));
document.querySelector('#searchTripDestination').addEventListener('click', () => searchPlace('destination'));
['tripOriginQuery', 'tripDestinationQuery'].forEach((id) => {
  const input = document.querySelector(`#${id}`);
  const type = id === 'tripOriginQuery' ? 'origin' : 'destination';
  input.addEventListener('input', () => schedulePlaceSearch(type));
  input.addEventListener('keydown', (event) => { if (event.key === 'Enter') { event.preventDefault(); clearTimeout(searchDebounceTimer); searchPlace(type); } });
});
document.querySelector('#tripSearchResults').addEventListener('click', (event) => { const option = event.target.closest('[data-trip-result]'); if (!option) return; const point = searchCandidates[Number(option.dataset.tripResult)]; if (!point) return; searchRequestId += 1; searchCandidates = []; document.querySelector('#tripSearchResults').hidden = true; setTripPoint(searchTarget, point, point.name); });
fuelPriceInput.addEventListener('input', updateTripSummary);
tripConsumptionInput.addEventListener('input', updateTripSummary);
tripDistanceInput.addEventListener('input', updateTripSummary);
document.querySelector('#locateMe').addEventListener('click', locateMe);
document.querySelector('#resetTrip').addEventListener('click', resetTrip);
document.querySelector('#swapTripPoints').addEventListener('click', swapTripPoints);

window.addEventListener('fuel-records-changed', () => { normalizeRecords(); const nextProfile = readStorage('fuel-car-profile', {}); profile.distances = nextProfile?.distances && typeof nextProfile.distances === 'object' ? nextProfile.distances : {}; profile.locations = nextProfile?.locations && typeof nextProfile.locations === 'object' ? nextProfile.locations : {}; renderCorrectionViews(); if (!document.querySelector('#comparisonMapPreview')?.hidden) showComparisonStationMap(selectedComparisonId || selectedAdjustedId || records[0]?.id); });
window.addEventListener('app-tab-change', (event) => {
  if (event.detail?.tab === 'comparison' && activeComparisonView !== 'base') renderCorrectionViews();
  if (event.detail?.tab === 'car') initMap();
});

normalizeRecords();
setComparisonMapOpen(true);
initSettings();
activateComparisonView('base');
updatePointMode();
updateTripSummary();
refreshIcons();
})();
