(function createAmapService(global) {
  let loadPromise = null;
  const pluginPromises = new Map();
  const searchCache = new Map();
  const pendingSearches = new Map();
  const CACHE_TTL = 10 * 60 * 1000;
  const CACHE_LIMIT = 80;

  function config() {
    try {
      const custom = JSON.parse(localStorage.getItem('fuel-amap-config') || '{}');
      if (custom.key && custom.securityJsCode) return custom;
    } catch {}
    return {};
  }

  function plugins(names = []) {
    const normalized = [...new Set(names)].sort();
    if (!normalized.length) return Promise.resolve(global.AMap);
    const key = normalized.join(',');
    if (!pluginPromises.has(key)) {
      pluginPromises.set(key, new Promise((resolve) => global.AMap.plugin(normalized, () => resolve(global.AMap))));
    }
    return pluginPromises.get(key);
  }

  function normalizeKey(value) {
    return String(value || '').trim().toLocaleLowerCase('zh-CN').replace(/\s+/g, ' ');
  }

  function pruneCache() {
    const now = Date.now();
    for (const [key, entry] of searchCache) {
      if (now - entry.time > CACHE_TTL) searchCache.delete(key);
    }
    while (searchCache.size > CACHE_LIMIT) searchCache.delete(searchCache.keys().next().value);
  }

  function load(names = []) {
    if (global.AMap) return plugins(names);
    if (!loadPromise) {
      loadPromise = new Promise((resolve, reject) => {
        const credentials = config();
        if (!credentials.key || !credentials.securityJsCode) return reject(new Error('missing-config'));
        global._AMapSecurityConfig = { securityJsCode: credentials.securityJsCode };
        const callback = '__fuelAmapReady';
        const existing = document.querySelector('script[data-fuel-amap]');
        const timeout = global.setTimeout(() => reject(new Error('timeout')), 15000);
        global[callback] = () => {
          global.clearTimeout(timeout);
          delete global[callback];
          global.AMap ? resolve(global.AMap) : reject(new Error('load'));
        };
        if (existing) return;
        const script = document.createElement('script');
        script.dataset.fuelAmap = 'true';
        script.async = true;
        script.onerror = () => { global.clearTimeout(timeout); reject(new Error('network')); };
        script.src = `https://webapi.amap.com/maps?v=2.0&key=${encodeURIComponent(credentials.key)}&callback=${callback}`;
        document.head.appendChild(script);
      }).catch((error) => { loadPromise = null; throw error; });
    }
    return loadPromise.then(() => plugins(names));
  }

  function cachedPlaceSearch(cacheKey, executor) {
    const key = normalizeKey(cacheKey);
    pruneCache();
    const cached = searchCache.get(key);
    if (cached && Date.now() - cached.time < CACHE_TTL) return Promise.resolve(cached.value);
    if (pendingSearches.has(key)) return pendingSearches.get(key);
    const request = Promise.resolve().then(executor).then((value) => {
      searchCache.delete(key);
      searchCache.set(key, { time: Date.now(), value });
      pruneCache();
      return value;
    }).finally(() => pendingSearches.delete(key));
    pendingSearches.set(key, request);
    return request;
  }

  global.FuelAmap = Object.freeze({ load, cachedPlaceSearch, clearSearchCache: () => searchCache.clear() });
})(window);
