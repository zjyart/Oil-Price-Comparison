import { clearLegacyRouteData, createRouteStore } from './route-v2/state.js';
import { createPointMarker, createRouteMap, searchPlaces } from './route-v2/amap-adapter.js';

const root = document.querySelector('#routeV2App');
const routeTab = document.querySelector('#tab-route');
if (root && routeTab?.dataset.featureDisabled !== 'true') {
  clearLegacyRouteData();
  const store = createRouteStore();
  const elements = {
    guide: root.querySelector('.route-v2-guide'),
    mapContainer: root.querySelector('#routeV2Map'),
    mapStatus: root.querySelector('#routeV2MapStatus'),
    originInput: root.querySelector('#routeV2OriginQuery'),
    destinationInput: root.querySelector('#routeV2DestinationQuery'),
    originAddress: root.querySelector('#routeV2OriginAddress'),
    destinationAddress: root.querySelector('#routeV2DestinationAddress'),
    searchState: root.querySelector('#routeV2SearchState'),
    searchResults: root.querySelector('#routeV2SearchResults'),
    confirm: root.querySelector('#routeV2ConfirmPoints'),
    swap: root.querySelector('#routeV2SwapPoints'),
    edit: root.querySelector('#routeV2EditPoints'),
    confirmed: root.querySelector('#routeV2ConfirmedPoints'),
  };

  let map;
  let mapPromise;
  let markers = { origin: null, destination: null };
  let activeSearchType = 'origin';
  let searchTimer;
  let searchSequence = 0;
  let candidates = [];

  function refreshIcons() {
    if (window.lucide) window.lucide.createIcons();
  }

  function locationText(point) {
    return [point?.city, point?.district, point?.address].filter(Boolean).join(' · ') || '高德地图位置';
  }

  function setSearchState(message, state = '') {
    elements.searchState.className = `route-v2-search-state${state ? ` ${state}` : ''}`;
    elements.searchState.querySelector('span').textContent = message;
  }

  function searchErrorMessage(error) {
    if (error.message === 'missing-config') return '请先在设置中填写高德 API';
    if (/DAILY_QUERY_OVER_LIMIT/.test(error.detail || '')) return '高德地点搜索今日额度已用完，请更换 Key 或稍后再试';
    if (/INVALID_USER_KEY|USERKEY_PLAT_NOMATCH/.test(error.detail || '')) return '高德 API 配置无效，请在设置中检查 Key';
    return '地点搜索失败，请稍后重试';
  }

  function setMapStatus(message, state = '') {
    elements.mapStatus.className = state;
    elements.mapStatus.textContent = message;
  }

  async function ensureMap() {
    if (map) return map;
    if (mapPromise) return mapPromise;
    setMapStatus('正在加载高德地图', 'loading');
    mapPromise = createRouteMap(elements.mapContainer)
      .then((instance) => {
        map = instance;
        setMapStatus('等待选择起点和终点');
        renderMapPoints(store.getState());
        return map;
      })
      .catch((error) => {
        mapPromise = null;
        setMapStatus(error.message === 'missing-config' ? '请先在设置中填写高德 API' : '高德地图加载失败', 'error');
        throw error;
      });
    return mapPromise;
  }

  function renderMapPoints(state) {
    if (!map || !window.AMap) return;
    Object.entries(markers).forEach(([type, marker]) => {
      if (marker) map.remove(marker);
      markers[type] = null;
    });
    ['origin', 'destination'].forEach((type) => {
      const point = state[type];
      if (point) markers[type] = createPointMarker(map, type, point);
    });
    const visibleMarkers = Object.values(markers).filter(Boolean);
    if (visibleMarkers.length > 1) map.setFitView(visibleMarkers, false, [80, 80, 80, 80], 14);
    else if (visibleMarkers.length === 1) { map.setCenter(visibleMarkers[0].getPosition()); map.setZoom(14); }
  }

  function renderConfirmedPoints(state) {
    if (!state.origin || !state.destination) { elements.confirmed.innerHTML = ''; return; }
    elements.confirmed.innerHTML = `
      <div><i class="route-v2-origin-dot"></i><span><small>起点</small><strong>${escapeHtml(state.origin.name)}</strong></span></div>
      <i data-lucide="arrow-down"></i>
      <div><i class="route-v2-destination-dot"></i><span><small>终点</small><strong>${escapeHtml(state.destination.name)}</strong></span></div>`;
  }

  function render(state) {
    const originText = state.origin?.name || '';
    const destinationText = state.destination?.name || '';
    if (document.activeElement !== elements.originInput) elements.originInput.value = originText;
    if (document.activeElement !== elements.destinationInput) elements.destinationInput.value = destinationText;
    elements.originAddress.textContent = state.origin ? locationText(state.origin) : '尚未选择';
    elements.destinationAddress.textContent = state.destination ? locationText(state.destination) : '尚未选择';
    elements.originAddress.classList.toggle('selected', Boolean(state.origin));
    elements.destinationAddress.classList.toggle('selected', Boolean(state.destination));
    elements.confirm.disabled = !(state.origin && state.destination);
    elements.guide.dataset.currentStep = String(state.step);
    root.querySelectorAll('[data-route-v2-stage]').forEach((stage) => {
      const active = Number(stage.dataset.routeV2Stage) === state.step;
      stage.hidden = !active;
      stage.classList.toggle('active', active);
    });
    root.querySelectorAll('[data-route-v2-step]').forEach((button) => {
      const step = Number(button.dataset.routeV2Step);
      button.classList.toggle('active', step === state.step);
      button.classList.toggle('complete', step < state.step);
      button.disabled = step > 2 || (step === 2 && !(state.origin && state.destination));
    });
    renderConfirmedPoints(state);
    renderMapPoints(state);
    refreshIcons();
  }

  function escapeHtml(value) {
    const node = document.createElement('span');
    node.textContent = String(value || '');
    return node.innerHTML;
  }

  function renderCandidates(items) {
    candidates = items;
    elements.searchResults.innerHTML = items.map((item, index) => `
      <button type="button" role="option" data-route-v2-result="${index}">
        <i data-lucide="map-pin"></i>
        <span><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(locationText(item))}</small></span>
        <i data-lucide="chevron-right"></i>
      </button>`).join('');
    elements.searchResults.hidden = !items.length;
    setSearchState(items.length ? `找到 ${items.length} 个地点，请选择准确位置` : '没有找到匹配地点', items.length ? 'ready' : 'error');
    refreshIcons();
  }

  async function runSearch(type, query) {
    const trimmed = query.trim();
    activeSearchType = type;
    if (trimmed.length < 2) {
      searchSequence += 1;
      elements.searchResults.hidden = true;
      setSearchState('输入两个字后实时搜索');
      return;
    }
    const sequence = ++searchSequence;
    elements.searchResults.hidden = true;
    setSearchState('正在搜索高德地点', 'loading');
    try {
      const items = await searchPlaces(trimmed);
      if (sequence !== searchSequence) return;
      renderCandidates(items);
    } catch (error) {
      if (sequence !== searchSequence) return;
      setSearchState(searchErrorMessage(error), 'error');
    }
  }

  function scheduleSearch(type, input) {
    window.clearTimeout(searchTimer);
    const selected = store.getState()[type];
    if (selected && input.value.trim() !== selected.name) store.clearPoint(type);
    searchTimer = window.setTimeout(() => runSearch(type, input.value), 320);
  }

  [[elements.originInput, 'origin'], [elements.destinationInput, 'destination']].forEach(([input, type]) => {
    input.addEventListener('focus', () => { activeSearchType = type; if (input.value.trim().length >= 2) scheduleSearch(type, input); });
    input.addEventListener('input', () => scheduleSearch(type, input));
    input.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      runSearch(type, input.value);
    });
  });

  elements.searchResults.addEventListener('click', (event) => {
    const button = event.target.closest('[data-route-v2-result]');
    if (!button) return;
    const point = candidates[Number(button.dataset.routeV2Result)];
    if (!point) return;
    const selectedInput = activeSearchType === 'origin' ? elements.originInput : elements.destinationInput;
    selectedInput.value = point.name;
    store.setPoint(activeSearchType, point);
    elements.searchResults.hidden = true;
    setSearchState(`${activeSearchType === 'origin' ? '起点' : '终点'}已选择：${point.name}`, 'ready');
    ensureMap().catch(() => {});
    const nextInput = activeSearchType === 'origin' ? elements.destinationInput : elements.originInput;
    if (!store.getState()[activeSearchType === 'origin' ? 'destination' : 'origin']) nextInput.focus();
  });

  root.addEventListener('click', (event) => {
    const clearButton = event.target.closest('[data-clear-route-point]');
    if (clearButton) {
      const type = clearButton.dataset.clearRoutePoint;
      store.clearPoint(type);
      const input = type === 'origin' ? elements.originInput : elements.destinationInput;
      input.value = '';
      input.focus();
      elements.searchResults.hidden = true;
      setSearchState('输入两个字后实时搜索');
      return;
    }
    const stepButton = event.target.closest('[data-route-v2-step]');
    if (stepButton && !stepButton.disabled && Number(stepButton.dataset.routeV2Step) === 1) store.editPoints();
  });

  elements.swap.addEventListener('click', () => store.swapPoints());
  elements.confirm.addEventListener('click', () => {
    if (store.confirmPoints()) {
      elements.searchResults.hidden = true;
      setMapStatus('起点和终点已确认', 'ready');
    }
  });
  elements.edit.addEventListener('click', () => store.editPoints());

  store.subscribe(render);
  render(store.getState());

  window.addEventListener('app-tab-change', (event) => {
    if (event.detail?.tab !== 'route') return;
    ensureMap().then(() => window.setTimeout(() => map?.resize(), 0)).catch(() => {});
  });
  if (window.location.hash === '#route') ensureMap().catch(() => {});
}
