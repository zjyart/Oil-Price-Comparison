const fields = {
  name: document.querySelector('#name'),
  brand: document.querySelector('#brand'),
  store: document.querySelector('#store'),
  source: document.querySelector('#source'),
  price: document.querySelector('#price'),
  amount: document.querySelector('#amount'),
  spent: document.querySelector('#spent'),
};

const output = {
  effective: document.querySelector('#effectivePrice'),
  original: document.querySelector('#originalTotal'),
  liters: document.querySelector('#actualLiters'),
  saved: document.querySelector('#savedAmount'),
  rate: document.querySelector('#discountRate'),
  verdict: document.querySelector('#verdict'),
  audit: document.querySelector('#auditText span'),
  meter: document.querySelector('#meterBar'),
  pin: document.querySelector('#meterPin'),
  status: document.querySelector('#resultStatus'),
  copy: document.querySelector('#copyResult'),
};

function readStorage(key, fallback) { try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch { return fallback; } }
const money = (value) => `¥${value.toFixed(2)}`;
const numberValue = (field) => Number.parseFloat(field.value) || 0;
const storedRecords = readStorage('fuel-comparisons', []);
let records = (Array.isArray(storedRecords) ? storedRecords : []).map(normalizeRecord).filter(Boolean);
let latestResult = null;
let toastTimer;
let baseSortMode = 'cost';
let selectedBaseId = '';

const pickerOptions = {
  brand: [
    { value: '', label: '选填 / 不指定', icon: 'fuel', tone: 'neutral' },
    { value: '中国石油', label: '中国石油', icon: 'droplets', tone: 'petrochina', asset: 'assets/brand-icons/petrochina.svg', assetType: 'brand' },
    { value: '中国石化', label: '中国石化', icon: 'flame', tone: 'sinopec', asset: 'assets/brand-icons/sinopec.svg', assetType: 'brand' },
    { value: '中国海油', label: '中国海油', icon: 'waves', tone: 'cnooc', asset: 'assets/brand-icons/cnooc.svg', assetType: 'brand' },
    { value: '中化', label: '中化', icon: 'hexagon', tone: 'sinochem', asset: 'assets/brand-icons/sinochem-symbol.jpg', assetType: 'brand' },
    { value: '中化道达尔', label: '中化道达尔', icon: 'badge', tone: 'total', asset: 'assets/brand-icons/totalenergies.svg', assetType: 'brand' },
    { value: '其他', label: '其他品牌', icon: 'ellipsis', tone: 'other' },
  ],
  source: [
    { value: '', label: '选填 / 不指定', icon: 'smartphone', tone: 'neutral' },
    { value: '京东养车', label: '京东养车', icon: 'car-front', tone: 'jd', asset: 'assets/app-icons/jd-auto.jpg' },
    { value: '高德地图', label: '高德地图', icon: 'navigation', tone: 'amap', asset: 'assets/app-icons/amap.jpg' },
    { value: '途虎养车', label: '途虎养车', icon: 'wrench', tone: 'tuhu', asset: 'assets/app-icons/tuhu.jpg' },
    { value: '平安车主', label: '平安好车主', icon: 'shield-check', tone: 'pingan', asset: 'assets/app-icons/pingan-owner.jpg' },
    { value: '其他', label: '其他来源', icon: 'ellipsis', tone: 'other' },
  ],
};
let activePicker = null;
let pickerIndex = 0;
let pickerScrollFrame;
let pickerDraft = { brand: '', source: '' };
let pickerOrder = { brand: pickerOptions.brand.map((option) => option.value), source: pickerOptions.source.map((option) => option.value) };
let selectedStation = null;
let stationCandidates = [];
let stationSearchTimer;
let stationSearchRequest = 0;
let stationSearchOrigin = null;
let wizardStep = 1;
let wizardAutoAdvanceTimer;
let comparisonCompleted = false;
const provinces = ['北京', '天津', '河北', '山西', '内蒙古', '辽宁', '吉林', '黑龙江', '上海', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北', '湖南', '广东', '广西', '海南', '重庆', '四川', '贵州', '云南', '西藏', '陕西', '甘肃', '青海', '宁夏', '新疆', '香港', '澳门', '台湾'];
const storedRecentFuelPrices = readStorage('fuel-recent-prices', {});
let recentFuelPrices = storedRecentFuelPrices && typeof storedRecentFuelPrices === 'object' && !Array.isArray(storedRecentFuelPrices) ? storedRecentFuelPrices : {};
let activeFuelGrade = '95';

function currentStationSearchSettings() {
  const value = readStorage('fuel-app-settings', {});
  const radius = [8, 20, 50].includes(Number(value.stationSearchRadius)) ? Number(value.stationSearchRadius) : 8;
  return { radius, autoExpand: value.autoExpandSearch === true };
}

function normalizeProvince(value = '') {
  const text = String(value).trim();
  return provinces.find((province) => text.startsWith(province)) || '';
}

function validStationPoint(point) { return point && Number.isFinite(Number(point.lat)) && Number.isFinite(Number(point.lng)); }
function pointDistanceKm(a, b) {
  const radians = (degrees) => degrees * Math.PI / 180;
  const lat1 = radians(Number(a.lat)); const lat2 = radians(Number(b.lat));
  const deltaLat = lat2 - lat1; const deltaLng = radians(Number(b.lng) - Number(a.lng));
  const value = Math.sin(deltaLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLng / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
}

function automaticPlanName(brand, store, source, fallbackIndex) {
  const cleanBrand = String(brand || '').trim();
  const cleanStore = String(store || '').trim();
  const compactBrand = cleanBrand.replace(/\s+/g, '');
  const compactStore = cleanStore.replace(/\s+/g, '');
  const station = cleanBrand && cleanStore && !compactStore.includes(compactBrand) ? `${cleanBrand} ${cleanStore}` : cleanStore || cleanBrand;
  return [station, source ? `· ${source}` : ''].filter(Boolean).join(' ') || `方案 ${fallbackIndex}`;
}

function displayPlanName(record) {
  const name = String(record?.name || '未命名方案').trim();
  const brand = String(record?.brand || '').trim();
  const repeatedPrefix = brand ? `${brand} ${brand}` : '';
  return repeatedPrefix && name.startsWith(repeatedPrefix) ? `${brand}${name.slice(repeatedPrefix.length)}` : name;
}

function setStationSearchStatus(message = '', state = '') {
  const status = document.querySelector('#stationSearchStatus');
  status.className = `station-search-status ${state}`.trim();
  status.textContent = message;
}

function closeStationResults() {
  const results = document.querySelector('#stationSearchResults');
  results.hidden = true;
  document.querySelector('#wizardStationQuery')?.setAttribute('aria-expanded', 'false');
}

function clearSelectedStation(keepStatus = false) {
  selectedStation = null;
  if (!keepStatus) setStationSearchStatus('');
}

function renderStationCandidates(candidates, { canExpand = false } = {}) {
  stationCandidates = candidates;
  const results = document.querySelector('#stationSearchResults');
  results.innerHTML = candidates.map((station, index) => {
    const distance = Number.isFinite(station.distance) ? `<b>${station.distance < 1 ? `${Math.round(station.distance * 1000)} m` : `${station.distance.toFixed(1)} km`}</b>` : '';
    return `<button type="button" role="option" data-station-index="${index}"><span class="station-result-icon"><i data-lucide="fuel"></i></span><span><strong>${escapeHtml(station.name)}</strong><small>${escapeHtml(station.address || '地址信息暂缺')}</small></span>${distance}<i data-lucide="chevron-right"></i></button>`;
  }).join('');
  if (canExpand) results.insertAdjacentHTML('beforeend', '<button class="station-expand-search" type="button" data-expand-station-search><i data-lucide="scan-search"></i><span><strong>扩大搜索范围</strong><small>继续查找 50 km 内的同品牌油站</small></span><i data-lucide="arrow-right"></i></button>');
  results.hidden = candidates.length === 0;
  document.querySelector('#wizardStationQuery')?.setAttribute('aria-expanded', String(candidates.length > 0));
  refreshIcons();
}

function loadAmapForStationSearch() {
  return window.FuelAmap
    ? window.FuelAmap.load(['AMap.PlaceSearch', 'AMap.Geolocation'])
    : Promise.reject(new Error('amap-service-unavailable'));
}

async function resolveStationSearchOrigin(AMap) {
  if (validStationPoint(stationSearchOrigin)) return stationSearchOrigin;
  const savedProfile = readStorage('fuel-car-profile', {});
  if (validStationPoint(savedProfile.origin)) {
    stationSearchOrigin = { lat: Number(savedProfile.origin.lat), lng: Number(savedProfile.origin.lng) };
    return stationSearchOrigin;
  }
  stationSearchOrigin = await new Promise((resolve) => {
    const geolocation = new AMap.Geolocation({ enableHighAccuracy: true, timeout: 8000, convert: true, showButton: false, showMarker: false, showCircle: false });
    geolocation.getCurrentPosition((status, result) => {
      if (status !== 'complete' || !result?.position) { resolve(null); return; }
      resolve({ lat: result.position.getLat(), lng: result.position.getLng() });
    });
  });
  if (stationSearchOrigin) {
    const profile = readStorage('fuel-car-profile', {});
    profile.origin = stationSearchOrigin;
    profile.coordinateSystem = 'gcj02';
    localStorage.setItem('fuel-car-profile', JSON.stringify(profile));
  }
  return stationSearchOrigin;
}

async function searchActualStations(force = false, requestedRadius) {
  const typed = document.querySelector('#wizardStationQuery')?.value.trim() || '';
  const brand = fields.brand.value && fields.brand.value !== '其他' ? fields.brand.value : '';
  const keyword = [brand, typed && typed !== selectedStation?.name ? typed : ''].filter(Boolean).join(' ') || '加油站';
  if (!force && !brand && typed.length < 2) { closeStationResults(); return; }
  const requestId = ++stationSearchRequest;
  setStationSearchStatus('正在通过高德查找附近油站…', 'loading');
  try {
    const AMap = await loadAmapForStationSearch();
    const origin = await resolveStationSearchOrigin(AMap);
    const service = new AMap.PlaceSearch({ type: '加油站', pageSize: 12, pageIndex: 1, extensions: 'all' });
    const executeSearch = (radius) => new Promise((resolve) => {
      const callback = (status, result) => resolve(status === 'complete' ? result?.poiList?.pois || [] : []);
      if (origin) service.searchNearBy(keyword, new AMap.LngLat(origin.lng, origin.lat), radius, callback);
      else service.search(keyword, callback);
    });
    const runSearch = (radius) => {
      const originKey = origin ? `${origin.lng.toFixed(3)},${origin.lat.toFixed(3)}` : 'global';
      const key = `station:${keyword}:${originKey}:${radius}`;
      return window.FuelAmap ? window.FuelAmap.cachedPlaceSearch(key, () => executeSearch(radius)) : executeSearch(radius);
    };
    const searchSettings = currentStationSearchSettings();
    const initialRadius = searchSettings.radius * 1000;
    let radius = Number(requestedRadius) || initialRadius;
    let response = await runSearch(radius);
    let expandedAutomatically = false;
    if (origin && searchSettings.autoExpand && !requestedRadius && radius < 50000 && response.length === 0) {
      radius = 50000;
      response = await runSearch(radius);
      expandedAutomatically = true;
    }
    if (requestId !== stationSearchRequest) return;
    const candidates = response.map((poi) => {
      const point = { lat: Number(poi.location?.getLat?.() ?? poi.location?.lat), lng: Number(poi.location?.getLng?.() ?? poi.location?.lng) };
      const addressParts = [poi.pname, poi.cityname, poi.adname, poi.address].filter((value, index, values) => value && values.indexOf(value) === index);
      return { stationId: `amap:${poi.id || `${point.lng.toFixed(6)},${point.lat.toFixed(6)}`}`, name: poi.name || '未命名加油站', address: addressParts.join(' '), province: normalizeProvince(poi.pname), ...point, distance: origin && validStationPoint(point) ? pointDistanceKm(origin, point) : NaN };
    }).filter(validStationPoint).sort((a, b) => (a.distance || Infinity) - (b.distance || Infinity));
    renderStationCandidates(candidates, { canExpand: Boolean(origin && radius < 50000) });
    const rangeLabel = origin ? `${Math.round(radius / 1000)} km` : '当前城市';
    setStationSearchStatus(candidates.length ? `${expandedAutomatically ? `${searchSettings.radius} km 内无结果，已自动扩大 · ` : ''}${rangeLabel} 内找到 ${candidates.length} 个相近油站` : `${rangeLabel} 内没有找到相近油站，可调整门店关键词`, candidates.length ? 'ready' : 'error');
  } catch (error) {
    if (requestId !== stationSearchRequest) return;
    closeStationResults();
    setStationSearchStatus(error?.message === 'missing-config' ? '请先在设置中填写高德 API，或手动填写门店名称' : '高德检索暂不可用，仍可手动填写门店名称', 'error');
  }
}

function calculate() {
  const price = numberValue(fields.price);
  const amount = numberValue(fields.amount);
  const spent = numberValue(fields.spent);
  if (!price || !amount || !spent) return null;
  const liters = amount / price;
  const effective = spent / liters;
  const saved = amount - spent;
  return { price, amount, liters, spent, original: amount, effective, saved, rate: (saved / amount) * 100 };
}

function normalizeRecord(record, fallbackId) {
  if (!record || typeof record !== 'object') return null;
  const price = Number(record.price); const liters = Number(record.liters); const spent = Number(record.spent); const amount = Number(record.amount || record.original || price * liters);
  if (![price, liters, spent, amount].every((value) => Number.isFinite(value) && value > 0)) return null;
  return { ...record, id: record.id ?? fallbackId ?? Date.now() + Math.random(), name: String(record.name || '未命名方案'), price, liters, spent, amount, original: amount, effective: spent / liters, saved: amount - spent, rate: ((amount - spent) / amount) * 100 };
}

function removeDistanceData(ids) {
  const profile = readStorage('fuel-car-profile', {});
  if (!profile || typeof profile !== 'object') return;
  if (!profile.distances || typeof profile.distances !== 'object') profile.distances = {};
  if (!profile.locations || typeof profile.locations !== 'object') profile.locations = {};
  ids.forEach((id) => { delete profile.distances[id]; delete profile.locations[id]; });
  localStorage.setItem('fuel-car-profile', JSON.stringify(profile));
}

function updateResult() {
  const result = calculate();
  latestResult = result;
  updateProgress();
  if (!result) {
    output.effective.textContent = '--';
    output.original.textContent = '--';
    output.liters.textContent = '--';
    output.saved.textContent = '--';
    output.rate.textContent = '--';
    output.verdict.textContent = '填完三个数字，即时得到结果';
    output.audit.textContent = '总优惠已包含优惠券、平台直降和服务费的共同影响。';
    output.meter.style.width = '0%';
    output.pin.style.left = '0%';
    output.status.className = '';
    output.status.innerHTML = '<i data-lucide="circle-dashed"></i> 等待数据';
    output.copy.disabled = true;
    refreshIcons();
    return;
  }

  output.effective.textContent = result.effective.toFixed(2);
  output.original.textContent = money(result.original);
  output.liters.textContent = `${result.liters.toFixed(2)} 升`;
  output.saved.textContent = `${result.saved >= 0 ? '+' : '-'}${money(Math.abs(result.saved))}`;
  output.saved.className = result.saved >= 0 ? 'positive' : 'negative';
  output.rate.textContent = `${result.rate >= 0 ? '' : '-'}${Math.abs(result.rate).toFixed(1)}%`;
  output.rate.className = result.rate >= 0 ? 'positive' : 'negative';
  output.verdict.textContent = result.saved > 0.01
    ? `比直接按油站价支付便宜 ${money(result.saved)}，每升少花 ${money(result.price - result.effective)}。`
    : result.saved < -0.01 ? `算上所有费用后反而多花 ${money(Math.abs(result.saved))}，这次活动不划算。` : '和油站原价基本相同，没有产生实际优惠。';
  output.audit.textContent = `按 ${money(result.original)} 的加油面额折算；总优惠已包含服务费等所有影响。`;

  const meter = Math.max(0, Math.min(100, result.rate * 5));
  output.meter.style.width = `${meter}%`;
  output.pin.style.left = `${meter}%`;
  output.status.className = 'ready';
  output.status.innerHTML = '<i data-lucide="check-circle-2"></i> 计算完成';
  output.copy.disabled = false;
  document.querySelector('.price-display').classList.remove('changed');
  void document.querySelector('.price-display').offsetWidth;
  document.querySelector('.price-display').classList.add('changed');
  refreshIcons();
}

function updateProgress() {
  const complete = [fields.amount, fields.price, fields.spent].filter((field) => numberValue(field) > 0).length;
  const progress = document.querySelector('#formProgress');
  progress.querySelector('strong').textContent = `${complete}/3`;
  progress.querySelectorAll('i').forEach((dot, index) => dot.classList.toggle('complete', index < complete));
  progress.classList.toggle('done', complete === 3);
}

function optionMarkup(option) {
  return `${optionIconMarkup(option)}<span>${escapeHtml(option.label)}</span>`;
}

function optionIconMarkup(option) { return option.asset ? `<span class="option-icon app-source-icon ${option.assetType === 'brand' ? 'brand-icon' : ''}"><img src="${option.asset}" alt="" /></span>` : `<span class="option-icon ${option.tone}"><i data-lucide="${option.icon}"></i></span>`; }

function updatePickerTrigger(type) {
  const option = pickerOptions[type].find((item) => item.value === fields[type].value) || pickerOptions[type][0];
  const trigger = document.querySelector(`[data-picker="${type}"]`);
  if (!trigger) return;
  trigger.querySelector('.picker-value').innerHTML = optionMarkup(option);
  trigger.classList.toggle('has-value', Boolean(option.value));
  refreshIcons();
}

function renderCombinedPickerTrigger() {
  const trigger = document.querySelector('[data-picker="combined"]');
  if (!trigger) return;
  const brand = pickerOptions.brand.find((item) => item.value === fields.brand.value) || pickerOptions.brand[0];
  const source = pickerOptions.source.find((item) => item.value === fields.source.value) || pickerOptions.source[0];
  const brandLabel = selectedStation?.name || (brand.value ? brand.label : '开始新方案');
  const sourceLabel = selectedStation ? [brand.label, source.label].filter(Boolean).join(' · ') : (source.value ? `${source.label} · 继续选择实际油站` : '选择品牌、油站和加油来源');
  const icons = brand.value && source.value ? `<span class="combined-icons">${optionIconMarkup(brand)}${optionIconMarkup(source)}</span>` : optionIconMarkup(source.value ? source : brand);
  trigger.querySelector('.combined-picker-value').innerHTML = `${icons}<span class="combined-copy"><strong>${escapeHtml(brandLabel)}</strong><small>${escapeHtml(sourceLabel)}</small></span>`;
  trigger.classList.toggle('has-value', Boolean(brand.value || source.value));
  refreshIcons();
}

function updateWheelSelection() {
  const wheel = document.querySelector('#wheelPicker');
  const center = wheel.scrollTop + wheel.clientHeight / 2;
  let closest = 0;
  let closestDistance = Infinity;
  wheel.querySelectorAll('.wheel-option').forEach((item, index) => {
    const distance = Math.abs(item.offsetTop + item.offsetHeight / 2 - center);
    if (distance < closestDistance) { closest = index; closestDistance = distance; }
    item.style.setProperty('--wheel-distance', Math.min(distance / 58, 2));
  });
  pickerIndex = closest;
  wheel.querySelectorAll('.wheel-option').forEach((item, index) => {
    item.classList.toggle('selected', index === pickerIndex);
    item.setAttribute('aria-selected', String(index === pickerIndex));
  });
}

function scrollPickerTo(index, smooth = true) {
  const wheel = document.querySelector('#wheelPicker');
  const option = wheel.querySelectorAll('.wheel-option')[index];
  if (!option) return;
  wheel.scrollTo({ top: option.offsetTop - (wheel.clientHeight - option.offsetHeight) / 2, behavior: smooth ? 'smooth' : 'auto' });
  pickerIndex = index;
  window.setTimeout(updateWheelSelection, smooth ? 180 : 0);
}

function renderPickerBoard() {
  const board = document.querySelector('#pickerBoard');
  board.innerHTML = ['brand', 'source'].map((type) => {
    const title = type === 'brand' ? '油站品牌' : '加油 App 来源';
    const hint = type === 'brand' ? '中国石油、石化等' : '优惠与服务来源';
    const options = pickerOrder[type].map((value) => pickerOptions[type].find((item) => item.value === value)).filter(Boolean);
    return `<section class="picker-column" data-picker-column="${type}"><div class="picker-column-head"><strong>${title}</strong><span>${hint}</span></div><div class="picker-options" data-picker-options="${type}">${options.map((option) => `<button class="picker-option ${pickerDraft[type] === option.value ? 'selected' : ''}" type="button" draggable="true" role="option" aria-selected="${pickerDraft[type] === option.value}" data-picker-option="${type}" data-value="${escapeHtml(option.value)}">${optionMarkup(option)}<i class="drag-handle" data-lucide="grip-vertical" aria-hidden="true"></i></button>`).join('')}</div></section>`;
  }).join('');
  refreshIcons();
}

function openPicker(type) {
  window.clearTimeout(wizardAutoAdvanceTimer);
  activePicker = type;
  pickerDraft = { brand: fields.brand.value, source: fields.source.value };
  renderPickerBoard();
  document.querySelector('#wizardStationQuery').value = selectedStation?.name || '';
  document.querySelector('#wizardAmount').value = fields.amount.value;
  document.querySelector('#wizardPrice').value = fields.price.value;
  document.querySelector('#wizardSpent').value = fields.spent.value;
  document.querySelector('#wizardError').textContent = '';
  setWizardStep(1);
  document.querySelector('#pickerDialog').showModal();
}

function applyPickerDraft() {
  ['brand', 'source'].forEach((type) => {
    fields[type].value = pickerDraft[type];
    fields[type].dispatchEvent(new Event('input', { bubbles: true }));
    updatePickerTrigger(type);
  });
}

function closePicker() {
  window.clearTimeout(wizardAutoAdvanceTimer);
  window.clearTimeout(stationSearchTimer);
  stationSearchRequest += 1;
  renderCombinedPickerTrigger();
  const trigger = document.querySelector(`[data-picker="${activePicker}"]`);
  document.querySelector('#pickerDialog').close();
  trigger?.focus();
  activePicker = null;
}

function updateWizardNavigation() {
  const next = document.querySelector('#confirmPicker');
  const label = next.querySelector('span');
  const ready = wizardStep === 1 ? Boolean(pickerDraft.brand && pickerDraft.source) : wizardStep === 2 ? Boolean(selectedStation) : true;
  next.disabled = !ready;
  label.textContent = wizardStep === 1 ? '下一步 · 查找油站' : wizardStep === 2 ? '下一步 · 填写金额' : '完成并加入比价';
  document.querySelector('#wizardBack').hidden = wizardStep === 1;
}

function advanceWizardToStations() {
  window.clearTimeout(wizardAutoAdvanceTimer);
  if (wizardStep !== 1 || !pickerDraft.brand || !pickerDraft.source) return;
  const brandChanged = fields.brand.value !== pickerDraft.brand;
  applyPickerDraft();
  if (brandChanged) { fields.store.value = ''; clearSelectedStation(); document.querySelector('#wizardStationQuery').value = ''; }
  setWizardStep(2);
  searchActualStations(true);
}

function scheduleWizardAutoAdvance() {
  window.clearTimeout(wizardAutoAdvanceTimer);
  if (wizardStep !== 1 || !pickerDraft.brand || !pickerDraft.source) return;
  document.querySelector('#confirmPicker span').textContent = '2 秒后自动继续';
  wizardAutoAdvanceTimer = window.setTimeout(advanceWizardToStations, 2000);
}

function syncWizardGrade() {
  document.querySelectorAll('[data-wizard-grade]').forEach((button) => {
    const selected = button.dataset.wizardGrade === activeFuelGrade;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  const recent = Number(recentFuelPrices[activeFuelGrade]);
  if (Number.isFinite(recent) && recent > 0 && !document.querySelector('#wizardPrice').value) document.querySelector('#wizardPrice').value = recent.toFixed(2);
}

function setWizardStep(step) {
  wizardStep = Math.max(1, Math.min(3, step));
  const titles = ['选择品牌与来源', '选择实际加油站', '填写本次结算'];
  document.querySelector('#wizardStepLabel').textContent = `第 ${wizardStep} 步，共 3 步`;
  document.querySelector('#pickerTitle').textContent = titles[wizardStep - 1];
  document.querySelectorAll('[data-wizard-step]').forEach((panel) => { panel.hidden = Number(panel.dataset.wizardStep) !== wizardStep; panel.classList.toggle('active', !panel.hidden); });
  document.querySelectorAll('.wizard-progress i').forEach((dot, index) => dot.classList.toggle('active', index < wizardStep));
  if (wizardStep === 3) {
    document.querySelector('#wizardStationSummary').textContent = `${selectedStation?.name || fields.store.value} · ${pickerDraft.source}`;
    syncWizardGrade();
  }
  updateWizardNavigation();
  refreshIcons();
}

function completeWizard() {
  const amount = Number(document.querySelector('#wizardAmount').value);
  const price = Number(document.querySelector('#wizardPrice').value);
  const spent = Number(document.querySelector('#wizardSpent').value);
  const error = document.querySelector('#wizardError');
  if (![amount, price, spent].every((value) => Number.isFinite(value) && value > 0)) { error.textContent = '请填写有效的加油面额、本次油价和总支出。'; return; }
  error.textContent = '';
  fields.amount.value = amount.toFixed(2);
  fields.price.value = price.toFixed(2);
  fields.spent.value = spent.toFixed(2);
  [fields.amount, fields.price, fields.spent].forEach((field) => field.dispatchEvent(new Event('input', { bubbles: true })));
  closePicker();
  document.querySelector('#fuelForm').requestSubmit();
}

function setComparisonCompleted(completed) {
  comparisonCompleted = completed;
  const form = document.querySelector('#fuelForm');
  const actions = document.querySelector('#formActions');
  const submit = document.querySelector('#addComparisonButton');
  const icon = submit.querySelector('[data-lucide]');
  form.classList.toggle('comparison-complete', completed);
  actions.classList.toggle('completed-state', completed);
  submit.classList.toggle('completed', completed);
  submit.disabled = completed;
  submit.querySelector('span').textContent = completed ? '已完成比价' : '加入比价';
  if (icon) icon.setAttribute('data-lucide', completed ? 'check' : 'plus');
  document.querySelector('#startNewPlan').hidden = !completed;
  document.querySelector('[data-picker="combined"]').disabled = completed;
  refreshIcons();
}

function resetPlanForm({ notify = false } = {}) {
  fields.name.value = '';
  fields.brand.value = '';
  fields.store.value = '';
  fields.source.value = '';
  clearSelectedStation();
  closeStationResults();
  renderCombinedPickerTrigger();
  fields.price.value = '';
  fields.amount.value = '';
  fields.spent.value = '';
  document.querySelectorAll('.amount-presets button').forEach((button) => button.classList.remove('selected'));
  updateFuelPricePresetSelection();
  document.querySelector('#formError').textContent = '';
  setComparisonCompleted(false);
  updateResult();
  if (notify) showToast('已重置输入');
}

function initGlassMotion() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  document.querySelectorAll('.tool-shell, .comparison-chart, .table-wrap').forEach((surface) => {
    surface.classList.add('glass-reactive');
    surface.addEventListener('pointermove', (event) => {
      const rect = surface.getBoundingClientRect();
      surface.style.setProperty('--mx', `${event.clientX - rect.left}px`);
      surface.style.setProperty('--my', `${event.clientY - rect.top}px`);
    });
  });
}

function launchConfetti() {
  document.querySelector('.celebration-layer')?.remove();
  const layer = document.createElement('div');
  layer.className = 'celebration-layer';
  layer.setAttribute('aria-hidden', 'true');
  const colors = ['#c9f27b', '#ff725e', '#63d7b0', '#ffd55a', '#ffffff'];
  for (let index = 0; index < 24; index += 1) {
    const piece = document.createElement('i');
    piece.className = `confetti-piece${index % 7 === 0 ? ' ribbon' : ''}`;
    piece.style.setProperty('--x', `${8 + Math.random() * 84}%`);
    piece.style.setProperty('--w', `${4 + Math.random() * 5}px`);
    piece.style.setProperty('--h', `${7 + Math.random() * 9}px`);
    piece.style.setProperty('--color', colors[index % colors.length]);
    piece.style.setProperty('--delay', `${Math.random() * 180}ms`);
    piece.style.setProperty('--duration', `${900 + Math.random() * 500}ms`);
    piece.style.setProperty('--drift', `${-55 + Math.random() * 110}px`);
    piece.style.setProperty('--spin', `${240 + Math.random() * 520}deg`);
    layer.appendChild(piece);
  }
  document.querySelector('.result-panel').appendChild(layer);
  setTimeout(() => layer.remove(), 1700);
}

function saveRecords() { localStorage.setItem('fuel-comparisons', JSON.stringify(records)); window.dispatchEvent(new CustomEvent('fuel-records-changed')); }

function renderRecords() {
  const body = document.querySelector('#comparisonBody');
  const empty = document.querySelector('#emptyState');
  const table = document.querySelector('#tableWrap');
  const mobile = document.querySelector('#mobileRecords');
  const chart = document.querySelector('#comparisonChart');
  const chartBars = document.querySelector('#chartBars');
  const countText = `${records.length} 个方案`;
  document.querySelector('#recordCount').textContent = countText;
  document.querySelector('#navCount').textContent = records.length;
  empty.hidden = records.length > 0;
  table.hidden = records.length === 0;
  mobile.hidden = records.length === 0;
  chart.hidden = records.length === 0;
  body.innerHTML = '';
  mobile.innerHTML = '';
  chartBars.innerHTML = '';
  if (!records.length) return;

  const sorted = [...records].sort((a, b) => baseSortMode === 'spent' ? a.spent - b.spent : baseSortMode === 'name' ? displayPlanName(a).localeCompare(displayPlanName(b), 'zh-CN') : a.effective - b.effective);
  const best = sorted[0].effective;
  sorted.forEach((record, index) => {
    const isBest = Math.abs(record.effective - best) < 0.001;
    const name = escapeHtml(displayPlanName(record));
    const rank = `<span class="rank ${isBest ? 'best' : ''}">${String(index + 1).padStart(2, '0')}</span>`;
    const tag = isBest ? '<span class="best-tag">最低</span>' : '';
    const savedClass = record.saved >= 0 ? 'positive' : 'negative';
    const row = document.createElement('tr');
    row.dataset.recordId = record.id;
    row.className = String(record.id) === String(selectedBaseId) ? 'selected' : '';
    row.innerHTML = `<td>${rank}</td><td>${name}${tag}</td><td>${money(record.price)}/升</td><td>${money(record.amount || record.original)}</td><td>${record.liters.toFixed(2)} 升</td><td>${money(record.spent)}</td><td><strong>${money(record.effective)}/升</strong></td><td class="${savedClass}">${record.saved >= 0 ? '+' : '-'}${money(Math.abs(record.saved))}</td><td><button class="edit-record" type="button" data-id="${record.id}" aria-label="调整本次方案 ${name}"><i data-lucide="sliders-horizontal"></i>调整</button><button class="delete-button" type="button" data-id="${record.id}" aria-label="删除 ${name}" title="删除"><i data-lucide="x"></i></button></td>`;
    body.appendChild(row);

    const maxCost = Math.max(...sorted.map((item) => item.effective));
    const minCost = Math.min(...sorted.map((item) => item.effective));
    const spread = Math.max(maxCost - minCost, maxCost * .08);
    const relativeWidth = 8 + ((record.effective - minCost) / spread) * 84;
    const chartRow = document.createElement('div');
    chartRow.className = `chart-row ${isBest ? 'best' : ''} ${String(record.id) === String(selectedBaseId) ? 'selected' : ''}`;
    chartRow.dataset.recordId = record.id;
    chartRow.innerHTML = `<span class="chart-label" title="${name}">${name}</span><div class="chart-track"><span class="chart-bar" style="--bar-width:${Math.min(100, relativeWidth)}%"></span></div><strong class="chart-value">${record.effective.toFixed(2)}</strong><span class="row-actions"><button class="row-edit-action" type="button" data-edit-record="${record.id}" aria-label="编辑方案"><i data-lucide="pencil"></i></button><button class="row-delete-action" type="button" data-delete-record="${record.id}" aria-label="删除方案"><i data-lucide="trash-2"></i></button></span>`;
    chartBars.appendChild(chartRow);

    const card = document.createElement('article');
    card.className = `record-card ${isBest ? 'best' : ''}`;
    card.innerHTML = `<div class="record-card-head"><div>${rank}<h3>${name}${tag}</h3></div><div><button class="edit-record" type="button" data-id="${record.id}" aria-label="调整本次方案 ${name}"><i data-lucide="sliders-horizontal"></i></button><button class="delete-button" type="button" data-id="${record.id}" aria-label="删除 ${name}" title="删除"><i data-lucide="x"></i></button></div></div><div class="record-card-price"><span>¥</span><strong>${record.effective.toFixed(2)}</strong><small>/ 升 · 真实每升成本</small></div><dl><div><dt>拟加油</dt><dd>${money(record.amount || record.original)}</dd></div><div><dt>推算油量</dt><dd>${record.liters.toFixed(2)} 升</dd></div><div><dt>实际省下</dt><dd class="${savedClass}">${record.saved >= 0 ? '+' : '-'}${money(Math.abs(record.saved))}</dd></div></dl>`;
    mobile.appendChild(card);
  });
  refreshIcons();
}

function refreshIcons() { if (window.lucide) window.lucide.createIcons(); }
function escapeHtml(value) { const div = document.createElement('div'); div.textContent = value; return div.innerHTML; }
function showToast(message) { const toast = document.querySelector('#toast'); toast.querySelector('span').textContent = message; toast.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 2200); }

function fillPriceFromRecent() {
  const price = Number(recentFuelPrices[activeFuelGrade]);
  if (!Number.isFinite(price) || price <= 0) return false;
  fields.price.value = price.toFixed(2);
  fields.price.dispatchEvent(new Event('input', { bubbles: true }));
  return true;
}

function renderRecentFuelPrices({ fillPrice = false } = {}) {
  document.querySelectorAll('[data-fuel-grade]').forEach((button) => {
    const price = Number(recentFuelPrices[button.dataset.fuelGrade]);
    const validPrice = Number.isFinite(price) && price > 0;
    button.dataset.fuelPrice = validPrice ? price.toFixed(2) : '';
    button.querySelector('span').textContent = validPrice ? price.toFixed(2) : '--';
    button.title = validPrice ? `${button.dataset.fuelGrade}号最近使用价 ${price.toFixed(2)} 元/升` : `选择${button.dataset.fuelGrade}号并输入本次油价`;
  });
  if (fillPrice) fillPriceFromRecent();
  updateFuelPricePresetSelection();
}

function initRecentFuelPrices() { renderRecentFuelPrices(); }

function updateFuelPricePresetSelection() {
  document.querySelectorAll('[data-fuel-price]').forEach((button) => {
    const selected = button.dataset.fuelGrade === activeFuelGrade;
    button.classList.toggle('selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
}

Object.values(fields).forEach((field) => field.addEventListener('input', () => {
  document.querySelectorAll('.amount-presets button').forEach((button) => button.classList.toggle('selected', button.dataset.amount === fields.amount.value));
  updateFuelPricePresetSelection();
  updateResult();
}));

document.querySelectorAll('.amount-presets button').forEach((button) => button.addEventListener('click', () => {
  fields.amount.value = button.dataset.amount;
  document.querySelectorAll('.amount-presets button').forEach((item) => item.classList.toggle('selected', item === button));
  updateResult();
  fields.price.focus();
}));

document.querySelectorAll('[data-fuel-price]').forEach((button) => button.addEventListener('click', () => {
  activeFuelGrade = button.dataset.fuelGrade;
  updateFuelPricePresetSelection();
  if (!button.dataset.fuelPrice) showToast(`已选择 ${activeFuelGrade} 号，保存方案后自动记忆价格`);
  else fillPriceFromRecent();
  fields.price.focus();
}));

document.querySelector('#fuelForm').addEventListener('submit', (event) => {
  event.preventDefault();
  if (comparisonCompleted) return;
  const result = calculate();
  const error = document.querySelector('#formError');
  if (!result) { error.textContent = '请填写有效的油站油价、拟加油面额和含服务费总支出。'; return; }
  error.textContent = '';
  const recordId = Date.now() + Math.random();
  const generatedName = automaticPlanName(fields.brand.value, fields.store.value, fields.source.value, records.length + 1);
  records.push({ ...result, id: recordId, brand: fields.brand.value, store: fields.store.value.trim(), source: fields.source.value, fuelGrade: activeFuelGrade, stationId: selectedStation?.stationId || '', name: fields.name.value.trim() || generatedName });
  recentFuelPrices[activeFuelGrade] = Number(result.price.toFixed(2));
  localStorage.setItem('fuel-recent-prices', JSON.stringify(recentFuelPrices));
  renderRecentFuelPrices();
  if (selectedStation) {
    const profile = readStorage('fuel-car-profile', {});
    if (!profile.locations || typeof profile.locations !== 'object') profile.locations = {};
    if (!profile.distances || typeof profile.distances !== 'object') profile.distances = {};
    profile.locations[recordId] = { stationId: selectedStation.stationId, name: selectedStation.name, address: selectedStation.address, province: selectedStation.province || '', lat: selectedStation.lat, lng: selectedStation.lng, source: 'amap-poi', updatedAt: new Date().toISOString() };
    if (validStationPoint(stationSearchOrigin)) {
      profile.origin = stationSearchOrigin;
      profile.coordinateSystem = 'gcj02';
      profile.distances[recordId] = Number(pointDistanceKm(stationSearchOrigin, selectedStation).toFixed(2));
    }
    localStorage.setItem('fuel-car-profile', JSON.stringify(profile));
  }
  saveRecords();
  renderRecords();
  setComparisonCompleted(true);
  launchConfetti();
  showToast('方案已加入比价');
});

document.querySelector('#fuelForm').addEventListener('keydown', (event) => {
  if (event.key !== 'Enter' || event.isComposing || event.target.tagName !== 'INPUT') return;
  event.preventDefault();
  event.currentTarget.requestSubmit();
});

document.querySelector('#baseSortMode').addEventListener('change', (event) => { baseSortMode = event.target.value; renderRecords(); });
document.querySelector('#chartBars').addEventListener('click', (event) => {
  const edit = event.target.closest('[data-edit-record]');
  const remove = event.target.closest('[data-delete-record]');
  if (edit) { event.stopPropagation(); openEditor(edit.dataset.editRecord); return; }
  if (remove) { event.stopPropagation(); removeDistanceData([remove.dataset.deleteRecord]); records = records.filter((record) => String(record.id) !== String(remove.dataset.deleteRecord)); saveRecords(); renderRecords(); showToast('方案已删除'); return; }
  const refuel = event.target.closest('[data-open-refuel]');
  const row = event.target.closest('[data-record-id]');
  if (refuel) { window.dispatchEvent(new CustomEvent('open-refuel-record', { detail: { comparisonId: refuel.dataset.openRefuel } })); return; }
  if (!row) return;
  selectedBaseId = row.dataset.recordId;
  document.querySelectorAll('#chartBars [data-record-id], #comparisonBody tr[data-record-id]').forEach((item) => item.classList.toggle('selected', item.dataset.recordId === selectedBaseId));
  window.dispatchEvent(new CustomEvent('comparison-station-select', { detail: { comparisonId: selectedBaseId } }));
});

window.addEventListener('comparison-map-base-select', (event) => {
  const id = String(event.detail?.comparisonId || '');
  if (!records.some((record) => String(record.id) === id)) return;
  selectedBaseId = id;
  document.querySelectorAll('#chartBars [data-record-id], #comparisonBody tr[data-record-id]').forEach((item) => item.classList.toggle('selected', String(item.dataset.recordId) === id));
  document.querySelector(`#chartBars [data-record-id="${CSS.escape(id)}"]`)?.scrollIntoView({ block: 'nearest' });
  window.dispatchEvent(new CustomEvent('comparison-station-select', { detail: { comparisonId: id } }));
});

window.addEventListener('delete-station-comparisons', (event) => {
  const ids = new Set((event.detail?.comparisonIds || []).map(String));
  if (!ids.size) return;
  removeDistanceData([...ids]);
  records = records.filter((record) => !ids.has(String(record.id)));
  saveRecords();
  renderRecords();
});

document.querySelector('#comparison').addEventListener('click', (event) => {
  const edit = event.target.closest('[data-edit-record]');
  const remove = event.target.closest('[data-delete-record]');
  if (edit) { openEditor(edit.dataset.editRecord); return; }
  if (remove) { removeDistanceData([remove.dataset.deleteRecord]); records = records.filter((record) => String(record.id) !== String(remove.dataset.deleteRecord)); saveRecords(); renderRecords(); showToast('方案已删除'); return; }
  const button = event.target.closest('.delete-button');
  if (!button) return;
  removeDistanceData([button.dataset.id]);
  records = records.filter((record) => String(record.id) !== button.dataset.id);
  saveRecords();
  renderRecords();
  showToast('方案已删除');
});

document.querySelector('#clearAll').addEventListener('click', () => {
  if (!records.length) { showToast('当前没有保存记录'); return; }
  if (window.confirm('确定清空所有比较记录吗？')) { removeDistanceData(records.map((record) => record.id)); records = []; saveRecords(); renderRecords(); showToast('记录已清空'); }
});

document.querySelector('#resetForm').addEventListener('click', () => resetPlanForm({ notify: true }));
document.querySelector('#startNewPlan').addEventListener('click', () => {
  resetPlanForm();
  openPicker('combined');
});

function openEditor(id) {
  const record = records.find((item) => String(item.id) === String(id));
  if (!record) return;
  document.querySelector('#editId').value = record.id;
  document.querySelector('#editName').value = displayPlanName(record);
  document.querySelector('#editPrice').value = record.price;
  document.querySelector('#editAmount').value = record.amount || record.original;
  document.querySelector('#editLiters').value = record.liters;
  document.querySelector('#editSpent').value = record.spent;
  document.querySelector('#editDialog').showModal();
}

document.querySelector('#comparison').addEventListener('click', (event) => {
  const button = event.target.closest('.edit-record');
  if (button) openEditor(button.dataset.id);
});

document.querySelector('#editForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const record = records.find((item) => String(item.id) === document.querySelector('#editId').value);
  if (!record) return;
  record.name = document.querySelector('#editName').value.trim() || record.name;
  record.price = Number(document.querySelector('#editPrice').value) || record.price;
  record.amount = Number(document.querySelector('#editAmount').value) || record.amount || record.original;
  record.liters = Number(document.querySelector('#editLiters').value) || record.amount / record.price;
  record.original = record.amount;
  record.spent = Number(document.querySelector('#editSpent').value) || record.spent;
  record.effective = record.spent / record.liters;
  record.saved = record.amount - record.spent;
  record.rate = (record.saved / record.amount) * 100;
  saveRecords();
  renderRecords();
  document.querySelector('#editDialog').close();
  showToast('方案已更新');
});
document.querySelector('#cancelEdit').addEventListener('click', () => document.querySelector('#editDialog').close());
document.querySelector('.station-management-link').addEventListener('click', () => document.querySelector('#editDialog').close());

document.querySelector('#exportData').addEventListener('click', () => {
  const payload = { version: 1, exportedAt: new Date().toISOString(), records, carProfile: readStorage('fuel-car-profile', {}) };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = `油价比一比-${new Date().toISOString().slice(0, 10)}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  showToast('数据已导出');
});

document.querySelector('#importData').addEventListener('change', async (event) => {
  const file = event.target.files?.[0]; if (!file) return;
  try {
    const payload = JSON.parse(await file.text());
    const imported = Array.isArray(payload) ? payload : payload.records;
    if (!Array.isArray(imported)) throw new Error('invalid');
    records = imported.map((record, index) => normalizeRecord(record, Date.now() + index)).filter(Boolean);
    if (payload.carProfile) localStorage.setItem('fuel-car-profile', JSON.stringify(payload.carProfile));
    saveRecords(); renderRecords(); showToast(`已导入 ${records.length} 个方案`);
  } catch { showToast('导入文件格式不正确'); }
  event.target.value = '';
});

document.querySelector('#copyResult').addEventListener('click', async () => {
  if (!latestResult) return;
  const text = `油价比一比\n真实每升成本：${money(latestResult.effective)}\n推算实际加油量：${latestResult.liters.toFixed(2)} 升\n实际省下：${money(latestResult.saved)}`;
  try { await navigator.clipboard.writeText(text); showToast('结果已复制'); } catch { showToast('当前浏览器不支持复制'); }
});

document.querySelectorAll('.picker-trigger').forEach((trigger) => trigger.addEventListener('click', () => openPicker(trigger.dataset.picker)));
document.querySelector('#cancelPicker').addEventListener('click', closePicker);
document.querySelector('#confirmPicker').addEventListener('click', () => {
  if (wizardStep === 1) { advanceWizardToStations(); return; }
  if (wizardStep === 2) { setWizardStep(3); return; }
  completeWizard();
});
document.querySelector('#wizardBack').addEventListener('click', () => setWizardStep(wizardStep - 1));
document.querySelector('#refreshStationSearch').addEventListener('click', () => searchActualStations(true));
document.querySelector('#wizardStationQuery').addEventListener('input', (event) => {
  if (selectedStation && event.target.value.trim() !== selectedStation.name) { clearSelectedStation(true); updateWizardNavigation(); }
  window.clearTimeout(stationSearchTimer);
  stationSearchTimer = window.setTimeout(() => searchActualStations(false), 450);
});
document.querySelector('#wizardStationQuery').addEventListener('keydown', (event) => {
  if (event.key !== 'Escape') return;
  event.preventDefault();
  event.stopPropagation();
  closeStationResults();
});
document.querySelector('#stationSearchResults').addEventListener('click', (event) => {
  if (event.target.closest('[data-expand-station-search]')) { searchActualStations(true, 50000); return; }
  const option = event.target.closest('[data-station-index]');
  if (!option) return;
  const station = stationCandidates[Number(option.dataset.stationIndex)];
  if (!station) return;
  selectedStation = station;
  fields.store.value = station.name;
  document.querySelector('#wizardStationQuery').value = station.name;
  closeStationResults();
  setStationSearchStatus(`已锚定 · ${station.address || '高德地图位置'}`, 'anchored');
  updateWizardNavigation();
  updateResult();
});
document.querySelectorAll('[data-wizard-amount]').forEach((button) => button.addEventListener('click', () => {
  document.querySelector('#wizardAmount').value = button.dataset.wizardAmount;
  document.querySelectorAll('[data-wizard-amount]').forEach((item) => item.classList.toggle('selected', item === button));
}));
document.querySelectorAll('[data-wizard-grade]').forEach((button) => button.addEventListener('click', () => {
  activeFuelGrade = button.dataset.wizardGrade;
  document.querySelector('#wizardPrice').value = '';
  syncWizardGrade();
}));
document.querySelector('#pickerDialog').addEventListener('cancel', (event) => {
  event.preventDefault();
  closePicker();
});
document.querySelector('#pickerBoard').addEventListener('click', (event) => {
  if (suppressPickerClick) return;
  const option = event.target.closest('.picker-option');
  if (!option) return;
  pickerDraft[option.dataset.pickerOption] = option.dataset.value;
  document.querySelectorAll(`[data-picker-option="${option.dataset.pickerOption}"]`).forEach((item) => {
    const selected = item === option;
    item.classList.toggle('selected', selected);
    item.setAttribute('aria-selected', String(selected));
  });
  updateWizardNavigation();
  scheduleWizardAutoAdvance();
});
document.querySelector('#pickerBoard').addEventListener('dragstart', (event) => {
  const option = event.target.closest('.picker-option');
  if (!option) return;
  option.classList.add('dragging');
  event.dataTransfer.effectAllowed = 'move';
  event.dataTransfer.setData('text/plain', `${option.dataset.pickerOption}\n${option.dataset.value}`);
});
document.querySelector('#pickerBoard').addEventListener('dragend', (event) => event.target.closest('.picker-option')?.classList.remove('dragging'));
document.querySelector('#pickerBoard').addEventListener('dragover', (event) => {
  if (event.target.closest('.picker-options')) event.preventDefault();
});
document.querySelector('#pickerBoard').addEventListener('drop', (event) => {
  const target = event.target.closest('.picker-option');
  const container = event.target.closest('.picker-options');
  if (!container) return;
  event.preventDefault();
  const [type, value] = event.dataTransfer.getData('text/plain').split('\n');
  if (container.dataset.pickerOptions !== type) return;
  if (target?.dataset.value === value) return;
  const order = pickerOrder[type].filter((item) => item !== value);
  const targetIndex = target ? order.indexOf(target.dataset.value) : order.length;
  order.splice(targetIndex < 0 ? order.length : targetIndex, 0, value);
  pickerOrder[type] = order;
  renderPickerBoard();
});

let pointerDrag = null;
let suppressPickerClick = false;
document.querySelector('#pickerBoard').addEventListener('pointerdown', (event) => {
  const option = event.target.closest('.picker-option');
  if (!option || event.button !== 0) return;
  pointerDrag = { option, type: option.dataset.pickerOption, value: option.dataset.value, x: event.clientX, y: event.clientY, moved: false };
  option.setPointerCapture?.(event.pointerId);
});
document.querySelector('#pickerBoard').addEventListener('pointermove', (event) => {
  if (!pointerDrag) return;
  const distance = Math.hypot(event.clientX - pointerDrag.x, event.clientY - pointerDrag.y);
  if (distance < 7) return;
  pointerDrag.moved = true;
  pointerDrag.option.classList.add('dragging');
  event.preventDefault();
});
document.querySelector('#pickerBoard').addEventListener('pointerup', (event) => {
  if (!pointerDrag) return;
  const drag = pointerDrag;
  pointerDrag = null;
  drag.option.classList.remove('dragging');
  if (!drag.moved) return;
  const target = document.elementFromPoint(event.clientX, event.clientY)?.closest('.picker-option');
  const container = target?.closest('.picker-options');
  if (container?.dataset.pickerOptions !== drag.type) return;
  if (target.dataset.value === drag.value) return;
  const order = pickerOrder[drag.type].filter((value) => value !== drag.value);
  const targetIndex = Math.max(0, order.indexOf(target.dataset.value));
  order.splice(targetIndex, 0, drag.value);
  pickerOrder[drag.type] = order;
  suppressPickerClick = true;
  renderPickerBoard();
  window.setTimeout(() => { suppressPickerClick = false; }, 0);
});
initRecentFuelPrices();
refreshIcons();
renderCombinedPickerTrigger();
updateResult();
renderRecords();
initGlassMotion();
