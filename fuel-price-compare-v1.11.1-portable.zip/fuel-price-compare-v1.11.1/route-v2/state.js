const STORAGE_KEY = 'fuel-route-v2-draft';
const LEGACY_KEYS = [
  'fuel-economy-route-points',
  'fuel-route-preferences',
  'fuel-saved-economy-routes',
];

function validPoint(point) {
  return point
    && Number.isFinite(Number(point.lng))
    && Number.isFinite(Number(point.lat))
    && Math.abs(Number(point.lng)) <= 180
    && Math.abs(Number(point.lat)) <= 90;
}

function normalizePoint(point) {
  if (!validPoint(point)) return null;
  return Object.freeze({
    id: String(point.id || ''),
    name: String(point.name || '').trim(),
    address: String(point.address || '').trim(),
    city: String(point.city || '').trim(),
    district: String(point.district || '').trim(),
    lng: Number(point.lng),
    lat: Number(point.lat),
    source: 'amap-place-search',
  });
}

function readDraft() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    return {
      step: stored.step === 2 ? 2 : 1,
      origin: normalizePoint(stored.origin),
      destination: normalizePoint(stored.destination),
    };
  } catch {
    return { step: 1, origin: null, destination: null };
  }
}

function persist(state) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    version: 2,
    step: state.step,
    origin: state.origin,
    destination: state.destination,
  }));
}

export function clearLegacyRouteData() {
  LEGACY_KEYS.forEach((key) => localStorage.removeItem(key));
}

export function createRouteStore() {
  let state = Object.freeze(readDraft());
  const listeners = new Set();

  function setState(patch) {
    const next = typeof patch === 'function' ? patch(state) : { ...state, ...patch };
    state = Object.freeze({
      step: next.step === 2 ? 2 : 1,
      origin: normalizePoint(next.origin),
      destination: normalizePoint(next.destination),
    });
    persist(state);
    listeners.forEach((listener) => listener(state));
  }

  return Object.freeze({
    getState: () => state,
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    setPoint(type, point) {
      if (!['origin', 'destination'].includes(type)) return;
      setState({ ...state, [type]: point, step: 1 });
    },
    clearPoint(type) {
      if (!['origin', 'destination'].includes(type)) return;
      setState({ ...state, [type]: null, step: 1 });
    },
    swapPoints() {
      setState({ ...state, origin: state.destination, destination: state.origin, step: 1 });
    },
    confirmPoints() {
      if (!state.origin || !state.destination) return false;
      setState({ ...state, step: 2 });
      return true;
    },
    editPoints() {
      setState({ ...state, step: 1 });
    },
  });
}

