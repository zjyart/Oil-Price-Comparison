function readJson(key, fallback = {}) {
  try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch { return fallback; }
}

export function loadAmap() {
  return window.FuelAmap
    ? window.FuelAmap.load(['AMap.PlaceSearch'])
    : Promise.reject(new Error('amap-service-unavailable'));
}

function pointFromPoi(poi) {
  const location = poi?.location;
  const lng = Number(location?.lng ?? location?.getLng?.());
  const lat = Number(location?.lat ?? location?.getLat?.());
  if (!Number.isFinite(lng) || !Number.isFinite(lat)) return null;
  return {
    id: poi.id,
    name: poi.name,
    address: typeof poi.address === 'string' ? poi.address : '',
    city: poi.cityname || '',
    district: poi.adname || '',
    lng,
    lat,
  };
}

export async function searchPlaces(query) {
  await loadAmap();
  const service = new window.AMap.PlaceSearch({ pageSize: 8, pageIndex: 1, extensions: 'all' });
  const execute = () => new Promise((resolve, reject) => {
    service.search(query, (status, result) => {
      if (status === 'no_data') { resolve([]); return; }
      if (status !== 'complete') {
        const error = new Error('search');
        error.detail = String(result?.info || result || status || 'unknown');
        reject(error);
        return;
      }
      resolve((result?.poiList?.pois || []).map(pointFromPoi).filter(Boolean));
    });
  });
  return window.FuelAmap.cachedPlaceSearch(`route:${query}`, execute);
}

export async function createRouteMap(container) {
  await loadAmap();
  const settings = readJson('fuel-app-settings');
  const map = new window.AMap.Map(container, {
    viewMode: '2D',
    center: [120.15, 30.28],
    zoom: 8,
    resizeEnable: true,
    mapStyle: settings.mapMode === 'satellite' ? undefined : 'amap://styles/darkblue',
  });
  if (settings.mapMode === 'satellite' && window.AMap.TileLayer?.Satellite) {
    const layers = [new window.AMap.TileLayer.Satellite({ zIndex: 0 })];
    if (window.AMap.TileLayer.RoadNet) layers.push(new window.AMap.TileLayer.RoadNet({ zIndex: 1 }));
    map.setLayers(layers);
  }
  if (settings.traffic && window.AMap.TileLayer?.Traffic) {
    map.add(new window.AMap.TileLayer.Traffic({ zIndex: 12, autoRefresh: true, interval: 180 }));
  }
  return map;
}

export function createPointMarker(map, type, point) {
  const label = type === 'origin' ? '起' : '终';
  return new window.AMap.Marker({
    map,
    position: [point.lng, point.lat],
    anchor: 'bottom-center',
    zIndex: type === 'origin' ? 140 : 150,
    content: `<div class="route-v2-map-marker ${type}"><b><i>${label}</i></b><span>${escapeText(point.name)}</span></div>`,
  });
}

function escapeText(value) {
  const node = document.createElement('span');
  node.textContent = String(value || '');
  return node.innerHTML;
}
