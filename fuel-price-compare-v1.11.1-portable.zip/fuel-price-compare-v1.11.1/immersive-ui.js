(function mountEnergyField() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const canvas = document.createElement('canvas');
  canvas.className = 'energy-field';
  canvas.setAttribute('aria-hidden', 'true');
  document.body.prepend(canvas);

  const gl = canvas.getContext('webgl', {
    alpha: true,
    antialias: false,
    depth: false,
    powerPreference: 'low-power',
  });
  if (!gl) { canvas.remove(); return; }

  const vertexSource = `
    attribute vec2 position;
    void main() { gl_Position = vec4(position, 0.0, 1.0); }
  `;
  const fragmentSource = `
    precision mediump float;
    uniform vec2 resolution;
    uniform vec2 pointer;
    uniform float time;

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
    }

    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      f = f * f * (3.0 - 2.0 * f);
      return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
                 mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0)), f.x), f.y);
    }

    float field(vec2 p) {
      float value = 0.0;
      float weight = 0.55;
      for (int i = 0; i < 4; i++) {
        value += noise(p) * weight;
        p = mat2(1.54, -1.18, 1.18, 1.54) * p + 0.17;
        weight *= 0.48;
      }
      return value;
    }

    void main() {
      vec2 uv = (gl_FragCoord.xy - 0.5 * resolution) / min(resolution.x, resolution.y);
      vec2 cursor = (pointer - 0.5) * vec2(resolution.x / resolution.y, 1.0);
      float drift = time * 0.035;
      float vapor = field(uv * 2.1 + vec2(drift, -drift * 0.7));
      float ribbon = 0.5 + 0.5 * sin(uv.x * 5.2 - uv.y * 3.6 + vapor * 4.0 + time * 0.12);
      float focus = exp(-3.2 * length(uv - cursor * 0.32));
      float horizon = exp(-2.6 * length(uv - vec2(-0.62, 0.42)));
      float energy = smoothstep(0.48, 0.9, vapor * 0.72 + ribbon * 0.28) * 0.34;
      vec3 graphite = vec3(0.035, 0.055, 0.05);
      vec3 ember = vec3(1.0, 0.29, 0.08);
      vec3 mint = vec3(0.28, 0.78, 0.57);
      vec3 color = graphite + ember * (energy + focus * 0.11) + mint * horizon * 0.045;
      float alpha = 0.38 + energy * 0.28 + focus * 0.05;
      gl_FragColor = vec4(color, alpha);
    }
  `;

  function shader(type, source) {
    const result = gl.createShader(type);
    gl.shaderSource(result, source);
    gl.compileShader(result);
    if (!gl.getShaderParameter(result, gl.COMPILE_STATUS)) return null;
    return result;
  }

  const vertex = shader(gl.VERTEX_SHADER, vertexSource);
  const fragment = shader(gl.FRAGMENT_SHADER, fragmentSource);
  if (!vertex || !fragment) { canvas.remove(); return; }

  const program = gl.createProgram();
  gl.attachShader(program, vertex);
  gl.attachShader(program, fragment);
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) { canvas.remove(); return; }
  gl.useProgram(program);

  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);
  const position = gl.getAttribLocation(program, 'position');
  gl.enableVertexAttribArray(position);
  gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);

  const resolution = gl.getUniformLocation(program, 'resolution');
  const pointer = gl.getUniformLocation(program, 'pointer');
  const time = gl.getUniformLocation(program, 'time');
  const cursor = { x: 0.72, y: 0.7 };
  let frame = 0;
  let previousFrame = 0;

  function resize() {
    const dpr = Math.min(devicePixelRatio || 1, 1.35);
    const width = Math.max(1, Math.round(innerWidth * dpr));
    const height = Math.max(1, Math.round(innerHeight * dpr));
    if (canvas.width === width && canvas.height === height) return;
    canvas.width = width;
    canvas.height = height;
    gl.viewport(0, 0, width, height);
  }

  function draw(now) {
    frame = requestAnimationFrame(draw);
    if (now - previousFrame < 32) return;
    previousFrame = now;
    resize();
    gl.uniform2f(resolution, canvas.width, canvas.height);
    gl.uniform2f(pointer, cursor.x, cursor.y);
    gl.uniform1f(time, now * 0.001);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }

  addEventListener('pointermove', (event) => {
    cursor.x = event.clientX / Math.max(innerWidth, 1);
    cursor.y = 1 - event.clientY / Math.max(innerHeight, 1);
  }, { passive: true });
  addEventListener('resize', resize, { passive: true });
  document.addEventListener('visibilitychange', () => {
    cancelAnimationFrame(frame);
    if (!document.hidden) frame = requestAnimationFrame(draw);
  });
  resize();
  frame = requestAnimationFrame(draw);
})();
