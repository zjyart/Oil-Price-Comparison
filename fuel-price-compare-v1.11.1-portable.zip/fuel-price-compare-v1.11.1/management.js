(function () {
function readStorage(key, fallback) { try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback)); } catch { return fallback; } }
function escapeHtml(value) { const div = document.createElement('div'); div.textContent = value; return div.innerHTML; }
function refreshIcons() { if (window.lucide) window.lucide.createIcons(); }
const money = (value) => `¥${Number(value).toFixed(2)}`;
const normalizeKey = (value) => String(value || '').trim().toLowerCase().replace(/\s+/g, '-').replace(/[^\w\u4e00-\u9fff-]/g, '');
function displayPlanName(record) {
  const name = String(record?.name || '未命名方案').trim();
  const brand = String(record?.brand || '').trim();
  const repeatedPrefix = brand ? `${brand} ${brand}` : '';
  return repeatedPrefix && name.startsWith(repeatedPrefix) ? `${brand}${name.slice(repeatedPrefix.length)}` : name;
}
const brandAssets = [
  ['中化道达尔', 'assets/brand-icons/totalenergies.svg'],
  ['中国石油', 'assets/brand-icons/petrochina.svg'],
  ['中国石化', 'assets/brand-icons/sinopec.svg'],
  ['中国海油', 'assets/brand-icons/cnooc.svg'],
  ['中化', 'assets/brand-icons/sinochem-symbol.jpg'],
];
function stationIconMarkup(station) {
  const asset = brandAssets.find(([brand]) => String(station?.brand || '').includes(brand))?.[1];
  return asset ? `<img src="${asset}" alt="" />` : '<i data-lucide="fuel"></i>';
}
let comparisons = [];
let refuelRecords = [];
let stations = [];
let selectedStationId = '';
let recordChartMetric = 'consumption';
let toastTimer;

function showToast(message) { const toast = document.querySelector('#toast'); toast.querySelector('span').textContent = message; toast.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 1700); }
function saveStations() { localStorage.setItem('fuel-stations', JSON.stringify(stations)); window.dispatchEvent(new CustomEvent('fuel-stations-changed')); }
function saveRefuelRecords() { localStorage.setItem('fuel-refuel-records', JSON.stringify(refuelRecords)); window.dispatchEvent(new CustomEvent('fuel-refuel-records-changed')); }

function migrateStations() {
  comparisons = Array.isArray(readStorage('fuel-comparisons', [])) ? readStorage('fuel-comparisons', []) : [];
  refuelRecords = Array.isArray(readStorage('fuel-refuel-records', [])) ? readStorage('fuel-refuel-records', []) : [];
  const storedStations = readStorage('fuel-stations', []);
  stations = Array.isArray(storedStations) ? storedStations.filter((station) => station?.id && station?.name) : [];
  const profile = readStorage('fuel-car-profile', {});
  let comparisonsChanged = false;
  comparisons.forEach((record) => {
    const location = profile?.locations?.[record.id];
    const stationName = String(location?.name || record.store || '').trim();
    if (!stationName) return;
    const stationId = String(record.stationId || location?.stationId || `legacy:${normalizeKey(stationName)}`);
    if (!record.stationId) { record.stationId = stationId; comparisonsChanged = true; }
    const existing = stations.find((station) => station.id === stationId);
    if (existing) {
      if (!existing.address && location?.address) existing.address = location.address;
      if (!existing.brand && record.brand) existing.brand = record.brand;
      return;
    }
    stations.push({ id: stationId, name: stationName, brand: record.brand || '', address: location?.address || '', phone: '', note: '', lat: location?.lat ?? null, lng: location?.lng ?? null, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
  });
  if (comparisonsChanged) localStorage.setItem('fuel-comparisons', JSON.stringify(comparisons));
  localStorage.setItem('fuel-stations', JSON.stringify(stations));
}

function stationById(id) { return stations.find((station) => String(station.id) === String(id)); }

function intervalMetrics() {
  const ordered = refuelRecords.filter((record) => Number.isFinite(Number(record.odometer)) && Number(record.odometer) > 0).sort((a, b) => Number(a.odometer) - Number(b.odometer) || String(a.date).localeCompare(String(b.date)));
  const previousById = new Map(ordered.map((record, index) => [String(record.id), ordered[index - 1]]));
  return refuelRecords.map((record) => {
    const previous = previousById.get(String(record.id));
    const distance = previous ? Number(record.odometer) - Number(previous.odometer) : 0;
    const validDistance = distance > 0;
    return { ...record, distance: validDistance ? distance : 0, consumption: validDistance ? Number(record.liters) / distance * 100 : null, costPerKm: validDistance ? Number(record.paid) / distance : null, price: Number(record.paid) / Number(record.liters) };
  });
}

function renderStationOptions(selected = '') {
  const select = document.querySelector('#refuelStation');
  select.innerHTML = stations.length ? stations.map((station) => `<option value="${escapeHtml(station.id)}">${escapeHtml(station.name)}</option>`).join('') : '<option value="">请先新增油站</option>';
  if (selected && stationById(selected)) select.value = selected;
}

function renderRefuelSummary(metrics) {
  const totalSpent = refuelRecords.reduce((sum, record) => sum + Number(record.paid || 0), 0);
  const totalLiters = refuelRecords.reduce((sum, record) => sum + Number(record.liters || 0), 0);
  const validIntervals = metrics.filter((record) => Number.isFinite(record.consumption));
  const intervalDistance = validIntervals.reduce((sum, record) => sum + record.distance, 0);
  const intervalLiters = validIntervals.reduce((sum, record) => sum + Number(record.liters), 0);
  const averageConsumption = intervalDistance ? intervalLiters / intervalDistance * 100 : null;
  document.querySelector('#refuelTotalSpent').textContent = refuelRecords.length ? money(totalSpent) : '--';
  document.querySelector('#refuelTotalLiters').textContent = refuelRecords.length ? totalLiters.toFixed(1) : '--';
  document.querySelector('#refuelAveragePrice').textContent = totalLiters ? (totalSpent / totalLiters).toFixed(2) : '--';
  document.querySelector('#refuelAverageConsumption').textContent = averageConsumption ? averageConsumption.toFixed(2) : '--';
  document.querySelector('#refuelRecordCount').textContent = `${refuelRecords.length} 条记录`;
  document.querySelector('#refuelNavCount').textContent = refuelRecords.length;
}

function chartValues(metrics) {
  if (recordChartMetric === 'price') return metrics.filter((record) => Number.isFinite(record.price)).map((record) => ({ ...record, value: record.price }));
  if (recordChartMetric === 'cost') return metrics.filter((record) => Number.isFinite(record.costPerKm)).map((record) => ({ ...record, value: record.costPerKm }));
  return metrics.filter((record) => Number.isFinite(record.consumption)).map((record) => ({ ...record, value: record.consumption }));
}

function renderLineChart(metrics) {
  const container = document.querySelector('#refuelLineChart');
  const values = chartValues(metrics);
  const labels = { consumption: ['百公里油耗', 'L / 100km'], price: ['每升油价', '元 / L'], cost: ['每公里成本', '元 / km'] };
  const [title, unit] = labels[recordChartMetric];
  document.querySelector('#refuelChartSummary').textContent = values.length ? `${title} · ${values.at(-1).value.toFixed(2)} ${unit}` : `至少需要${recordChartMetric === 'price' ? '一' : '两'}条记录`;
  if (!values.length) { container.innerHTML = '<div class="records-chart-empty"><i data-lucide="chart-no-axes-combined"></i><span>继续添加记录后显示趋势</span></div>'; refreshIcons(); return; }
  const width = 760; const height = 210; const pad = { left: 50, right: 20, top: 20, bottom: 36 };
  const rawMin = Math.min(...values.map((item) => item.value)); const rawMax = Math.max(...values.map((item) => item.value));
  const spread = Math.max(rawMax - rawMin, Math.max(rawMax * .12, .1)); const min = Math.max(0, rawMin - spread * .25); const max = rawMax + spread * .25;
  const x = (index) => pad.left + (values.length === 1 ? (width - pad.left - pad.right) / 2 : index / (values.length - 1) * (width - pad.left - pad.right));
  const y = (value) => pad.top + (max - value) / (max - min) * (height - pad.top - pad.bottom);
  const points = values.map((item, index) => `${x(index).toFixed(1)},${y(item.value).toFixed(1)}`).join(' ');
  const grid = [0, .25, .5, .75, 1].map((ratio) => { const gy = pad.top + ratio * (height - pad.top - pad.bottom); const value = max - ratio * (max - min); return `<line x1="${pad.left}" y1="${gy}" x2="${width - pad.right}" y2="${gy}"/><text x="${pad.left - 8}" y="${gy + 3}" text-anchor="end">${value.toFixed(1)}</text>`; }).join('');
  const dots = values.map((item, index) => `<circle cx="${x(index)}" cy="${y(item.value)}" r="4"><title>${escapeHtml(item.date)} · ${item.value.toFixed(2)} ${unit}</title></circle>`).join('');
  const dates = values.length === 1 ? `<text x="${x(0)}" y="${height - 10}" text-anchor="middle">${escapeHtml(values[0].date.slice(5))}</text>` : `<text x="${x(0)}" y="${height - 10}">${escapeHtml(values[0].date.slice(5))}</text><text x="${x(values.length - 1)}" y="${height - 10}" text-anchor="end">${escapeHtml(values.at(-1).date.slice(5))}</text>`;
  container.innerHTML = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${title}趋势图"><g class="chart-grid">${grid}</g><polyline class="chart-area-line" points="${points}"/><g class="chart-dots">${dots}</g><g class="chart-dates">${dates}</g></svg>`;
}

function renderRefuelRecords() {
  const metrics = intervalMetrics();
  renderRefuelSummary(metrics);
  renderLineChart(metrics);
  const metricById = new Map(metrics.map((record) => [String(record.id), record]));
  const body = document.querySelector('#refuelRecordBody');
  const sorted = [...refuelRecords].sort((a, b) => String(b.date).localeCompare(String(a.date)) || Number(b.odometer) - Number(a.odometer));
  body.innerHTML = sorted.map((record) => {
    const station = stationById(record.stationId); const metric = metricById.get(String(record.id));
    const odometerText = Number(record.odometer) > 0 ? `${Number(record.odometer).toFixed(1)} km` : '--';
    return `<tr><td>${escapeHtml(record.date)}</td><td><strong>${escapeHtml(station?.name || record.stationName || '未知油站')}</strong>${record.note ? `<small>${escapeHtml(record.note)}</small>` : ''}</td><td>${escapeHtml(record.grade || '95')}号</td><td>${odometerText}</td><td>${Number(record.liters).toFixed(2)} L</td><td>${money(Number(record.paid))}</td><td>${money(metric?.price || 0)}</td><td>${metric?.consumption ? `${metric.consumption.toFixed(2)} L/100km` : '--'}</td><td><button class="record-row-action" type="button" data-edit-refuel="${record.id}" aria-label="编辑 ${escapeHtml(record.date)} 加油记录"><i data-lucide="sliders-horizontal"></i></button><button class="record-row-action danger" type="button" data-delete-refuel="${record.id}" aria-label="删除 ${escapeHtml(record.date)} 加油记录"><i data-lucide="trash-2"></i></button></td></tr>`;
  }).join('');
  document.querySelector('#refuelEmpty').hidden = refuelRecords.length > 0;
  refreshIcons();
}

function stationAssociations(stationId) {
  return { plans: comparisons.filter((record) => String(record.stationId) === String(stationId)), fills: refuelRecords.filter((record) => String(record.stationId) === String(stationId)) };
}

function renderStationList() {
  const query = document.querySelector('#stationManagerSearch').value.trim().toLowerCase();
  const filtered = stations.filter((station) => [station.name, station.brand, station.address].some((value) => String(value || '').toLowerCase().includes(query)));
  const list = document.querySelector('#stationManagerList');
  list.innerHTML = filtered.length ? filtered.map((station) => { const associated = stationAssociations(station.id); const lowest = associated.plans.length ? Math.min(...associated.plans.map((record) => Number(record.effective))) : null; return `<button class="station-manager-item ${String(station.id) === String(selectedStationId) ? 'selected' : ''}" type="button" data-station-manager-id="${escapeHtml(station.id)}"><span>${stationIconMarkup(station)}</span><div><strong>${escapeHtml(station.name)}</strong><small>${escapeHtml(station.brand || '未设置品牌')} · ${lowest ? `最低 ${money(lowest)}/升` : '暂无方案价'}</small></div><i data-lucide="chevron-right"></i></button>`; }).join('') : '<div class="station-list-empty"><i data-lucide="search-x"></i><span>没有匹配的油站</span></div>';
  refreshIcons();
}

function renderStationDetail() {
  const detail = document.querySelector('#stationManagerDetail');
  const station = stationById(selectedStationId);
  if (!station) { detail.innerHTML = '<div class="station-manager-empty"><i data-lucide="fuel"></i><strong>选择一个油站</strong><span>查看资料、方案和实际加油记录</span></div>'; refreshIcons(); return; }
  const { plans, fills } = stationAssociations(station.id);
  const lowestPlanPrice = plans.length ? Math.min(...plans.map((record) => Number(record.effective))) : null;
  const latestFill = [...fills].sort((a, b) => String(b.date).localeCompare(String(a.date)))[0];
  const latestFillPrice = latestFill && Number(latestFill.liters) > 0 ? Number(latestFill.paid) / Number(latestFill.liters) : null;
  const planRows = plans.length ? plans.map((record) => `<tr><td>${escapeHtml(displayPlanName(record))}</td><td>${money(Number(record.effective))}/升</td><td>${money(Number(record.spent))}</td><td>${escapeHtml(record.source || '--')}</td></tr>`).join('') : '<tr><td colspan="4" class="association-empty">暂无关联方案</td></tr>';
  const fillRows = fills.length ? [...fills].sort((a, b) => String(b.date).localeCompare(String(a.date))).map((record) => `<tr><td>${escapeHtml(record.date)}</td><td>${escapeHtml(record.grade)}号</td><td>${Number(record.liters).toFixed(2)} L</td><td>${money(Number(record.paid))}</td></tr>`).join('') : '<tr><td colspan="4" class="association-empty">暂无实际加油记录</td></tr>';
  detail.innerHTML = `<header class="station-profile-head"><div><span>${stationIconMarkup(station)}</span><div><strong>${escapeHtml(station.name)}</strong><small>${escapeHtml(station.brand || '未设置品牌')}</small></div></div><button class="small-action" type="button" data-edit-station="${escapeHtml(station.id)}"><i data-lucide="pencil"></i>编辑资料</button></header><div class="station-profile-meta"><div><span>地址</span><strong>${escapeHtml(station.address || '未填写')}</strong></div><div><span>联系电话</span><strong>${escapeHtml(station.phone || '未填写')}</strong></div><div><span>最低方案价</span><strong>${lowestPlanPrice ? `${money(lowestPlanPrice)}/升` : '--'}</strong></div><div><span>最近实付价</span><strong>${latestFillPrice ? `${money(latestFillPrice)}/升` : '--'}</strong></div></div>${station.note ? `<p class="station-profile-note"><i data-lucide="notebook-pen"></i>${escapeHtml(station.note)}</p>` : ''}<div class="station-association-tabs"><section><header><strong>比价方案</strong><span>${plans.length} 条</span></header><div><table><thead><tr><th>方案</th><th>真实每升</th><th>支出</th><th>来源</th></tr></thead><tbody>${planRows}</tbody></table></div></section><section><header><strong>实际加油</strong><span>${fills.length} 条</span></header><div><table><thead><tr><th>日期</th><th>标号</th><th>加油量</th><th>实付</th></tr></thead><tbody>${fillRows}</tbody></table></div></section></div>`;
  const editButton = detail.querySelector('[data-edit-station]');
  if (editButton) {
    const actions = document.createElement('div');
    actions.className = 'station-profile-actions';
    const deleteButton = document.createElement('button');
    deleteButton.className = 'small-action danger';
    deleteButton.type = 'button';
    deleteButton.dataset.deleteStation = station.id;
    deleteButton.innerHTML = '<i data-lucide="trash-2"></i>删除油站';
    editButton.replaceWith(actions);
    actions.append(editButton, deleteButton);
  }
  refreshIcons();
}

function renderStations() {
  if (!selectedStationId && stations[0]) selectedStationId = stations[0].id;
  if (selectedStationId && !stationById(selectedStationId)) selectedStationId = stations[0]?.id || '';
  renderStationList();
  renderStationDetail();
  renderStationOptions();
}

function openRefuelDialog(id = '') {
  const record = refuelRecords.find((item) => String(item.id) === String(id));
  document.querySelector('#refuelId').value = record?.id || '';
  document.querySelector('#refuelDialogTitle').textContent = record ? '编辑加油记录' : '记录加油';
  document.querySelector('#refuelDate').value = record?.date || new Date().toISOString().slice(0, 10);
  renderStationOptions(record?.stationId || selectedStationId || stations[0]?.id || '');
  document.querySelector('#refuelOdometer').value = record?.odometer || '';
  document.querySelector('#refuelGrade').value = record?.grade || '95';
  document.querySelector('#refuelLiters').value = record?.liters || '';
  document.querySelector('#refuelPaid').value = record?.paid || '';
  document.querySelector('#refuelNote').value = record?.note || '';
  document.querySelector('#refuelError').textContent = '';
  document.querySelector('#refuelDialog').showModal();
}

function recordComparisonAsRefuel(comparisonId) {
  const comparison = comparisons.find((record) => String(record.id) === String(comparisonId));
  if (!comparison) { showToast('未找到对应方案'); return; }
  let stationId = comparison.stationId || `legacy:${normalizeKey(comparison.store || displayPlanName(comparison))}`;
  if (!stationById(stationId)) {
    const stationName = String(comparison.store || displayPlanName(comparison)).trim() || '未命名油站';
    stations.push({ id: stationId, name: stationName, brand: comparison.brand || '', address: '', phone: '', note: '', lat: null, lng: null, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    comparison.stationId = stationId;
    localStorage.setItem('fuel-comparisons', JSON.stringify(comparisons));
    saveStations();
  }
  refuelRecords.push({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, date: new Date().toISOString().slice(0, 10), stationId, odometer: null, grade: comparison.fuelGrade || '95', liters: Number(comparison.liters), paid: Number(comparison.spent), note: `来自方案：${displayPlanName(comparison)}` });
  saveRefuelRecords(); renderRefuelRecords(); renderStations(); showToast('已直接记入加油记录');
}

function openStationDialog(id = '') {
  const station = stationById(id);
  document.querySelector('#stationEditId').value = station?.id || '';
  document.querySelector('#stationDialogTitle').textContent = station ? '编辑油站资料' : '新增油站';
  document.querySelector('#stationEditName').value = station?.name || '';
  document.querySelector('#stationEditBrand').value = station?.brand || '';
  document.querySelector('#stationEditPhone').value = station?.phone || '';
  document.querySelector('#stationEditAddress').value = station?.address || '';
  document.querySelector('#stationEditNote').value = station?.note || '';
  document.querySelector('#stationError').textContent = '';
  document.querySelector('#stationDialog').showModal();
}

function deleteManagedStation(id) {
  const station = stationById(id);
  if (!station) return;
  const { plans, fills } = stationAssociations(id);
  const message = `确定删除“${station.name}”吗？\n\n将同时删除 ${plans.length} 条关联比价方案和 ${fills.length} 条加油记录。`;
  if (!window.confirm(message)) return;
  const comparisonIds = plans.map((record) => String(record.id));
  stations = stations.filter((item) => String(item.id) !== String(id));
  refuelRecords = refuelRecords.filter((record) => String(record.stationId) !== String(id));
  selectedStationId = stations[0]?.id || '';
  saveStations();
  saveRefuelRecords();
  window.dispatchEvent(new CustomEvent('delete-station-comparisons', { detail: { comparisonIds } }));
  migrateStations();
  renderStations();
  renderRefuelRecords();
  showToast('油站及关联记录已删除');
}

document.querySelector('#addRefuelRecord').addEventListener('click', () => { if (!stations.length) { showToast('请先新增一个油站'); openStationDialog(); return; } openRefuelDialog(); });
document.querySelector('#closeRefuelDialog').addEventListener('click', () => document.querySelector('#refuelDialog').close());
document.querySelector('#refuelForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const values = { id: document.querySelector('#refuelId').value || `${Date.now()}-${Math.random().toString(16).slice(2)}`, date: document.querySelector('#refuelDate').value, stationId: document.querySelector('#refuelStation').value, odometer: Number(document.querySelector('#refuelOdometer').value), grade: document.querySelector('#refuelGrade').value, liters: Number(document.querySelector('#refuelLiters').value), paid: Number(document.querySelector('#refuelPaid').value), note: document.querySelector('#refuelNote').value.trim() };
  if (!values.date || !values.stationId || ![values.liters, values.paid].every((value) => Number.isFinite(value) && value > 0) || (document.querySelector('#refuelOdometer').value && (!Number.isFinite(values.odometer) || values.odometer <= 0))) { document.querySelector('#refuelError').textContent = '请填写日期、油站、加油量和实际支付；里程表可选。'; return; }
  const index = refuelRecords.findIndex((record) => String(record.id) === String(values.id));
  if (index >= 0) refuelRecords[index] = values; else refuelRecords.push(values);
  saveRefuelRecords(); document.querySelector('#refuelDialog').close(); renderRefuelRecords(); renderStations(); showToast(index >= 0 ? '加油记录已更新' : '加油记录已保存');
});
document.querySelector('#refuelRecordBody').addEventListener('click', (event) => {
  const edit = event.target.closest('[data-edit-refuel]'); const remove = event.target.closest('[data-delete-refuel]');
  if (edit) openRefuelDialog(edit.dataset.editRefuel);
  if (remove) { refuelRecords = refuelRecords.filter((record) => String(record.id) !== String(remove.dataset.deleteRefuel)); saveRefuelRecords(); renderRefuelRecords(); renderStations(); showToast('加油记录已删除'); }
});
document.querySelectorAll('[data-record-chart]').forEach((button) => button.addEventListener('click', () => { recordChartMetric = button.dataset.recordChart; document.querySelectorAll('[data-record-chart]').forEach((item) => { const active = item === button; item.classList.toggle('active', active); item.setAttribute('aria-selected', String(active)); }); renderLineChart(intervalMetrics()); }));

document.querySelector('#addStation').addEventListener('click', () => openStationDialog());
document.querySelector('#closeStationDialog').addEventListener('click', () => document.querySelector('#stationDialog').close());
document.querySelector('#stationForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const id = document.querySelector('#stationEditId').value || `station:${Date.now()}`;
  const old = stationById(id);
  const name = document.querySelector('#stationEditName').value.trim();
  if (!name) { document.querySelector('#stationError').textContent = '请填写油站名称。'; return; }
  const next = { ...(old || {}), id, name, brand: document.querySelector('#stationEditBrand').value.trim(), phone: document.querySelector('#stationEditPhone').value.trim(), address: document.querySelector('#stationEditAddress').value.trim(), note: document.querySelector('#stationEditNote').value.trim(), createdAt: old?.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() };
  const index = stations.findIndex((station) => station.id === id); if (index >= 0) stations[index] = next; else stations.push(next);
  if (old) {
    comparisons.forEach((record) => { if (String(record.stationId) !== String(id)) return; record.store = name; record.brand = next.brand; if (old.name && record.name.includes(old.name)) record.name = record.name.replace(old.name, name); record.name = displayPlanName(record); });
    localStorage.setItem('fuel-comparisons', JSON.stringify(comparisons));
    const profile = readStorage('fuel-car-profile', {}); Object.entries(profile.locations || {}).forEach(([recordId, location]) => { const record = comparisons.find((item) => String(item.id) === String(recordId)); if (String(record?.stationId) === String(id)) { location.name = name; location.address = next.address || location.address; } }); localStorage.setItem('fuel-car-profile', JSON.stringify(profile));
    window.dispatchEvent(new CustomEvent('fuel-records-changed'));
  }
  selectedStationId = id; saveStations(); document.querySelector('#stationDialog').close(); renderStations(); showToast(old ? '油站资料已同步更新' : '油站已新增');
});
document.querySelector('#stationManagerList').addEventListener('click', (event) => { const item = event.target.closest('[data-station-manager-id]'); if (!item) return; selectedStationId = item.dataset.stationManagerId; renderStations(); });
document.querySelector('#stationManagerDetail').addEventListener('click', (event) => { const edit = event.target.closest('[data-edit-station]'); const remove = event.target.closest('[data-delete-station]'); if (edit) openStationDialog(edit.dataset.editStation); if (remove) deleteManagedStation(remove.dataset.deleteStation); });
document.querySelector('#stationManagerSearch').addEventListener('input', renderStationList);

window.addEventListener('open-refuel-record', (event) => {
  recordComparisonAsRefuel(event.detail?.comparisonId);
});

['refuelDialog', 'stationDialog'].forEach((id) => document.querySelector(`#${id}`).addEventListener('cancel', (event) => { event.preventDefault(); event.currentTarget.close(); }));
window.addEventListener('fuel-records-changed', () => { migrateStations(); renderStations(); renderRefuelRecords(); });
window.addEventListener('app-tab-change', (event) => { if (event.detail?.tab === 'records') renderRefuelRecords(); if (event.detail?.tab === 'stations') renderStations(); });
window.addEventListener('comparison-view-change', (event) => { if (event.detail?.view === 'manager') renderStations(); });

migrateStations();
renderStations();
renderRefuelRecords();
})();
