@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto no_python
start "Fuel App Server" py -3 -m http.server 4190 --bind 127.0.0.1
timeout /t 1 /nobreak >nul
start "" "http://127.0.0.1:4190/index.html"
exit /b 0

:no_python
echo.
echo Unable to start. Please install Python 3 from https://www.python.org/downloads/
pause
